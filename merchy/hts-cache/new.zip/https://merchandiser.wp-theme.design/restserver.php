<!DOCTYPE html>

<!--[if IE 9]>
<html class="ie ie9" lang="en-US">
<![endif]-->

<html lang="en-US">

<head>
    <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Chrome, Firefox OS, Opera and Vivaldi -->
    <meta name="theme-color" content="#23282d">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#23282d">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#23282d">

	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="https://merchandiser.wp-theme.design/xmlrpc.php">

    				<script>document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script>
			<title>Page not found &#8211; Merchandiser</title>
 <link rel='dns-prefetch' href='//platform-api.sharethis.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//fonts.gstatic.com' />
<link rel='dns-prefetch' href='//ajax.googleapis.com' />
<link rel='dns-prefetch' href='//apis.google.com' />
<link rel='dns-prefetch' href='//google-analytics.com' />
<link rel='dns-prefetch' href='//www.google-analytics.com' />
<link rel='dns-prefetch' href='//ssl.google-analytics.com' />
<link rel='dns-prefetch' href='//youtube.com' />
<link rel='dns-prefetch' href='//s.gravatar.com' />
<link rel="alternate" type="application/rss+xml" title="Merchandiser &raquo; Feed" href="https://merchandiser.wp-theme.design/feed/" />
<link rel="alternate" type="application/rss+xml" title="Merchandiser &raquo; Comments Feed" href="https://merchandiser.wp-theme.design/comments/feed/" />
<link rel='stylesheet' id='wp-block-library-group-css' href='https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/plugins/bwp-minify/cache/minify-b1-wp-block-library-fb27739e7a188d6390962c16237c574c.css?ver=1568217794' type='text/css' media='all' />
<style id='yith-wcwl-main-inline-css' type='text/css'>
.wishlist_table .add_to_cart, a.add_to_wishlist.button.alt { border-radius: 16px; -moz-border-radius: 16px; -webkit-border-radius: 16px; }
</style>
<style id='getbowtied-styles-inline-css' type='text/css'>


	html,
	.woocommerce-account .woocommerce table.my_account_orders .woocommerce-orders-table__cell-order-actions .button
	{
		font-size: 18px;
	}

	body,
	.page-wrapper,
	.woocommerce ul.products li.product .product_thumbnail .shop_product_buttons_wrapper,
	.woocommerce ul.products li.product .shop_product_metas,
	.offcanvas_quickview .product-images-wrapper .fade-gradient,
	.site-header .header-wrapper .tools .myaccount-dropdown ul,
	.offcanvas_quickview,
	#expand_this,
	body.blog:not(.woocommerce) .blog_layout_1 .sticky_post_container .sticky_meta, 
	body.archive:not(.woocommerce) .blog_layout_1 .sticky_post_container .sticky_meta,
	body.blog:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post:nth-child(8n+2):nth-child(even) .post_content_wrapper,
	body.blog:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post:nth-child(4n+3) .post_content_wrapper,
	body.blog:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post:nth-child(4n+4) .post_content_wrapper,
	body.blog:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post:nth-child(8n+5):nth-child(odd) .post_content_wrapper,
	body.archive:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post:nth-child(8n+2):nth-child(odd) .post_content_wrapper, 
	body.archive:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post:nth-child(8n+5):nth-child(odd) .post_content_wrapper, 
	body.blog:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post:nth-child(8n+2):nth-child(odd) .post_content_wrapper,
	body.archive:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post:nth-child(8n+2):nth-child(2n) .post_content_wrapper,
	body.archive:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post:nth-child(4n+3) .post_content_wrapper,
	body.archive:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post:nth-child(4n+4) .post_content_wrapper,
	body.archive:not(.woocommerce) .blog_layout_default .sticky-post .sticky-title, 
	body.blog:not(.woocommerce) .blog_layout_default .sticky-post .sticky-title,
	body.archive:not(.woocommerce) .blog_layout_default ul.blog_posts li header .entry-title, 
	body.blog:not(.woocommerce) .blog_layout_default ul.blog_posts li header .entry-title,
	body.archive:not(.woocommerce) .blog_layout_default ul.blog_posts li header .entry-meta, 
	body.blog:not(.woocommerce) .blog_layout_default ul.blog_posts li header .entry-meta,
	.woocommerce table.variations td.label select option, .woocommerce table.variations td.value select option,
	.woocommerce-account .woocommerce form.edit-account,
	fieldset legend,
	.myaccount-popup,
	.woocommerce-account .woocommerce #customer_login,
	.offcanvas_aside,
	.offcanvas_minicart p.total,
	.search_wrapper .search-widget-area,
	.vc_tta-color-white.vc_tta-style-flat .vc_tta-tab.vc_active>a,
	.categories_layout_default .woocommerce .shortcode_products li.category_item .category_name a,
	.autocomplete-suggestions
	{
		background: #fff;
	}


		 .site-header .site-branding .site-title a,
		 .site-header .tools a.tools_button,
		 .site-header .main-navigation-slices > ul > li > a,
		 .site-header .main-navigation-flyout > ul > li > a,
		 .site-header .header-wrapper .tools a.tools_button,
		 .site-header .header-wrapper .tools a.tools_button:hover,
		 .site-header .site-branding .site-title a,
		 .site-header-mobiles .site-branding .site-title a,
		 .site-header-mobiles .tools a.tools_button,
		 .site-header-mobiles .nav ul li div,
		 .site-header-mobiles .header-wrapper-mobiles .tools a.tools_button,
		 .site-header-mobiles .site-branding .site-title a
		{
			color: #fff;
		}

		 .site-header .header-wrapper .tools ul li a.tools_button .tools_button_icon.uploaded_icon svg,
		 .site-header .header-wrapper .tools ul li span.tools_button .tools_button_icon.uploaded_icon svg,
		 .site-header-mobiles .header-wrapper-mobiles .tools ul li a.tools_button .tools_button_icon.uploaded_icon svg,
		 .site-header-mobiles .header-wrapper-mobiles .tools ul li span.tools_button .tools_button_icon.uploaded_icon svg
		{
			fill: #fff;
		}

		 .site-header .main-navigation-flyout > ul > li.menu-item-has-children > a:after,
		 .site-header .main-navigation-slices > ul > li.menu-item-has-children > a:after
		{
			content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 7.4296875 9.5 L 5.9296875 11 L 12 17.070312 L 18.070312 11 L 16.570312 9.5 L 12 14.070312 L 7.4296875 9.5 z'></path></svg>")
		}

		 .site-header .main-navigation-flyout > ul > li:not(.mega-menu) ul li.menu-item-has-children > a:after
		{
			content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 10 5.9296875 L 8.5 7.4296875 L 13.070312 12 L 8.5 16.570312 L 10 18.070312 L 16.070312 12 L 10 5.9296875 z'></path></svg>")
		}

		 .site-header .header-wrapper .tools a.tools_button .tools_button_icon.shopping-cart-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 4.4140625 1.9960938 L 1.0039062 2.0136719 L 1.0136719 4.0136719 L 3.0839844 4.0039062 L 6.3789062 11.908203 L 5.1816406 13.824219 C 4.7816406 14.464219 4.7609531 15.272641 5.1269531 15.931641 C 5.4929531 16.590641 6.1874063 17 6.9414062 17 L 19 17 L 19 15 L 6.9414062 15 L 6.8769531 14.882812 L 8.0527344 13 L 15.521484 13 C 16.248484 13 16.917531 12.604703 17.269531 11.970703 L 20.873047 5.4863281 C 21.046047 5.1763281 21.041328 4.7981875 20.861328 4.4921875 C 20.681328 4.1871875 20.352047 4 19.998047 4 L 5.25 4 L 4.4140625 1.9960938 z M 6.0820312 6 L 18.298828 6 L 15.521484 11 L 8.1660156 11 L 6.0820312 6 z M 7 18 A 2 2 0 0 0 5 20 A 2 2 0 0 0 7 22 A 2 2 0 0 0 9 20 A 2 2 0 0 0 7 18 z M 17 18 A 2 2 0 0 0 15 20 A 2 2 0 0 0 17 22 A 2 2 0 0 0 19 20 A 2 2 0 0 0 17 18 z'></path></svg>")
		}

		 .site-header .header-wrapper .tools a.tools_button .tools_button_icon.search-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z'></path></svg>")
		}

		 .site-header .header-wrapper .tools a.tools_button .tools_button_icon.wishlist-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M16.5,3C13.605,3,12,5.09,12,5.09S10.395,3,7.5,3C4.462,3,2,5.462,2,8.5c0,4.171,4.912,8.213,6.281,9.49 C9.858,19.46,12,21.35,12,21.35s2.142-1.89,3.719-3.36C17.088,16.713,22,12.671,22,8.5C22,5.462,19.538,3,16.5,3z M14.811,16.11 c-0.177,0.16-0.331,0.299-0.456,0.416c-0.751,0.7-1.639,1.503-2.355,2.145c-0.716-0.642-1.605-1.446-2.355-2.145 c-0.126-0.117-0.28-0.257-0.456-0.416C7.769,14.827,4,11.419,4,8.5C4,6.57,5.57,5,7.5,5c1.827,0,2.886,1.275,2.914,1.308L12,8 l1.586-1.692C13.596,6.295,14.673,5,16.5,5C18.43,5,20,6.57,20,8.5C20,11.419,16.231,14.827,14.811,16.11z'></path></svg>")
		}

		 .site-header .header-wrapper .tools a.tools_button .tools_button_icon.account-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 12 3 C 9.8027056 3 8 4.8027056 8 7 C 8 9.1972944 9.8027056 11 12 11 C 14.197294 11 16 9.1972944 16 7 C 16 4.8027056 14.197294 3 12 3 z M 12 5 C 13.116414 5 14 5.8835859 14 7 C 14 8.1164141 13.116414 9 12 9 C 10.883586 9 10 8.1164141 10 7 C 10 5.8835859 10.883586 5 12 5 z M 12 14 C 10.255047 14 8.1871638 14.409783 6.4492188 15.095703 C 5.5802462 15.438663 4.7946961 15.84605 4.1660156 16.369141 C 3.5373351 16.892231 3 17.599384 3 18.5 L 3 21 L 21 21 L 21 20 L 21 18.5 C 21 17.599384 20.462665 16.892231 19.833984 16.369141 C 19.205304 15.84605 18.419754 15.438663 17.550781 15.095703 C 15.812836 14.409783 13.744953 14 12 14 z M 12 16 C 13.414047 16 15.346055 16.373999 16.818359 16.955078 C 17.554512 17.245618 18.176961 17.591965 18.554688 17.90625 C 18.932412 18.220535 19 18.434616 19 18.5 L 19 19 L 5 19 L 5 18.5 C 5 18.434616 5.0675867 18.220535 5.4453125 17.90625 C 5.8230383 17.591965 6.4454882 17.245618 7.1816406 16.955078 C 8.6539455 16.373999 10.585953 16 12 16 z'></path></svg>")
		}

		 .site-header .header-wrapper .tools ul li a.tools_button .shopping_bag_items_number,
		 .site-header .header-wrapper .tools ul li a.tools_button .wishlist_items_number
		{
			background-color: #fff;
			color: #23282d;
		}
	

		.header-transparent-light:not(.header-sticky-scroll) .site-header .site-branding .site-title a,
		.header-transparent-light:not(.header-sticky-scroll) .site-header .tools a.tools_button,
		.header-transparent-light:not(.header-sticky-scroll) .site-header .main-navigation-slices > ul > li > a,
		.header-transparent-light:not(.header-sticky-scroll) .site-header .main-navigation-flyout > ul > li > a,
		.header-transparent-light:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button,
		.header-transparent-light:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button:hover,
		.header-transparent-light:not(.header-sticky-scroll) .site-header .site-branding .site-title a,
		.header-transparent-light:not(.header-sticky-scroll) .site-header-mobiles .site-branding .site-title a,
		.header-transparent-light:not(.header-sticky-scroll) .site-header-mobiles .tools a.tools_button,
		.header-transparent-light:not(.header-sticky-scroll) .site-header-mobiles .nav ul li div,
		.header-transparent-light:not(.header-sticky-scroll) .site-header-mobiles .header-wrapper-mobiles .tools a.tools_button,
		.header-transparent-light:not(.header-sticky-scroll) .site-header-mobiles .site-branding .site-title a
		{
			color: #fff;
		}

		.header-transparent-light:not(.header-sticky-scroll) .site-header .header-wrapper .tools ul li a.tools_button .tools_button_icon.uploaded_icon svg,
		.header-transparent-light:not(.header-sticky-scroll) .site-header .header-wrapper .tools ul li span.tools_button .tools_button_icon.uploaded_icon svg,
		.header-transparent-light:not(.header-sticky-scroll) .site-header-mobiles .header-wrapper-mobiles .tools ul li a.tools_button .tools_button_icon.uploaded_icon svg,
		.header-transparent-light:not(.header-sticky-scroll) .site-header-mobiles .header-wrapper-mobiles .tools ul li span.tools_button .tools_button_icon.uploaded_icon svg
		{
			fill: #fff;
		}

		.header-transparent-light:not(.header-sticky-scroll) .site-header .main-navigation-flyout > ul > li.menu-item-has-children > a:after,
		.header-transparent-light:not(.header-sticky-scroll) .site-header .main-navigation-slices > ul > li.menu-item-has-children > a:after
		{
			content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 7.4296875 9.5 L 5.9296875 11 L 12 17.070312 L 18.070312 11 L 16.570312 9.5 L 12 14.070312 L 7.4296875 9.5 z'></path></svg>")
		}

		.header-transparent-light:not(.header-sticky-scroll) .site-header .main-navigation-flyout > ul > li:not(.mega-menu) ul li.menu-item-has-children > a:after
		{
			content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 10 5.9296875 L 8.5 7.4296875 L 13.070312 12 L 8.5 16.570312 L 10 18.070312 L 16.070312 12 L 10 5.9296875 z'></path></svg>")
		}

		.header-transparent-light:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button .tools_button_icon.shopping-cart-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 4.4140625 1.9960938 L 1.0039062 2.0136719 L 1.0136719 4.0136719 L 3.0839844 4.0039062 L 6.3789062 11.908203 L 5.1816406 13.824219 C 4.7816406 14.464219 4.7609531 15.272641 5.1269531 15.931641 C 5.4929531 16.590641 6.1874063 17 6.9414062 17 L 19 17 L 19 15 L 6.9414062 15 L 6.8769531 14.882812 L 8.0527344 13 L 15.521484 13 C 16.248484 13 16.917531 12.604703 17.269531 11.970703 L 20.873047 5.4863281 C 21.046047 5.1763281 21.041328 4.7981875 20.861328 4.4921875 C 20.681328 4.1871875 20.352047 4 19.998047 4 L 5.25 4 L 4.4140625 1.9960938 z M 6.0820312 6 L 18.298828 6 L 15.521484 11 L 8.1660156 11 L 6.0820312 6 z M 7 18 A 2 2 0 0 0 5 20 A 2 2 0 0 0 7 22 A 2 2 0 0 0 9 20 A 2 2 0 0 0 7 18 z M 17 18 A 2 2 0 0 0 15 20 A 2 2 0 0 0 17 22 A 2 2 0 0 0 19 20 A 2 2 0 0 0 17 18 z'></path></svg>")
		}

		.header-transparent-light:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button .tools_button_icon.search-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z'></path></svg>")
		}

		.header-transparent-light:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button .tools_button_icon.wishlist-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M16.5,3C13.605,3,12,5.09,12,5.09S10.395,3,7.5,3C4.462,3,2,5.462,2,8.5c0,4.171,4.912,8.213,6.281,9.49 C9.858,19.46,12,21.35,12,21.35s2.142-1.89,3.719-3.36C17.088,16.713,22,12.671,22,8.5C22,5.462,19.538,3,16.5,3z M14.811,16.11 c-0.177,0.16-0.331,0.299-0.456,0.416c-0.751,0.7-1.639,1.503-2.355,2.145c-0.716-0.642-1.605-1.446-2.355-2.145 c-0.126-0.117-0.28-0.257-0.456-0.416C7.769,14.827,4,11.419,4,8.5C4,6.57,5.57,5,7.5,5c1.827,0,2.886,1.275,2.914,1.308L12,8 l1.586-1.692C13.596,6.295,14.673,5,16.5,5C18.43,5,20,6.57,20,8.5C20,11.419,16.231,14.827,14.811,16.11z'></path></svg>")
		}

		.header-transparent-light:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button .tools_button_icon.account-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 12 3 C 9.8027056 3 8 4.8027056 8 7 C 8 9.1972944 9.8027056 11 12 11 C 14.197294 11 16 9.1972944 16 7 C 16 4.8027056 14.197294 3 12 3 z M 12 5 C 13.116414 5 14 5.8835859 14 7 C 14 8.1164141 13.116414 9 12 9 C 10.883586 9 10 8.1164141 10 7 C 10 5.8835859 10.883586 5 12 5 z M 12 14 C 10.255047 14 8.1871638 14.409783 6.4492188 15.095703 C 5.5802462 15.438663 4.7946961 15.84605 4.1660156 16.369141 C 3.5373351 16.892231 3 17.599384 3 18.5 L 3 21 L 21 21 L 21 20 L 21 18.5 C 21 17.599384 20.462665 16.892231 19.833984 16.369141 C 19.205304 15.84605 18.419754 15.438663 17.550781 15.095703 C 15.812836 14.409783 13.744953 14 12 14 z M 12 16 C 13.414047 16 15.346055 16.373999 16.818359 16.955078 C 17.554512 17.245618 18.176961 17.591965 18.554688 17.90625 C 18.932412 18.220535 19 18.434616 19 18.5 L 19 19 L 5 19 L 5 18.5 C 5 18.434616 5.0675867 18.220535 5.4453125 17.90625 C 5.8230383 17.591965 6.4454882 17.245618 7.1816406 16.955078 C 8.6539455 16.373999 10.585953 16 12 16 z'></path></svg>")
		}

		.header-transparent-light:not(.header-sticky-scroll) .site-header .header-wrapper .tools ul li a.tools_button .shopping_bag_items_number,
		.header-transparent-light:not(.header-sticky-scroll) .site-header .header-wrapper .tools ul li a.tools_button .wishlist_items_number
		{
			background-color: #fff;
			color: #000;
		}
	

		.header-transparent-dark:not(.header-sticky-scroll) .site-header .site-branding .site-title a,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header .tools a.tools_button,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header .main-navigation-slices > ul > li > a,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header .main-navigation-flyout > ul > li > a,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button:hover,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header .site-branding .site-title a,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header-mobiles .site-branding .site-title a,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header-mobiles .tools a.tools_button,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header-mobiles .nav ul li div,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header-mobiles .header-wrapper-mobiles .tools a.tools_button,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header-mobiles .site-branding .site-title a
		{
			color: #000;
		}

		.header-transparent-dark:not(.header-sticky-scroll) .site-header .header-wrapper .tools ul li a.tools_button .tools_button_icon.uploaded_icon svg,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header .header-wrapper .tools ul li span.tools_button .tools_button_icon.uploaded_icon svg,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header-mobiles .header-wrapper-mobiles .tools ul li a.tools_button .tools_button_icon.uploaded_icon svg,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header-mobiles .header-wrapper-mobiles .tools ul li span.tools_button .tools_button_icon.uploaded_icon svg
		{
			fill: #000;
		}

		.header-transparent-dark:not(.header-sticky-scroll) .site-header .main-navigation-flyout > ul > li.menu-item-has-children > a:after,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header .main-navigation-slices > ul > li.menu-item-has-children > a:after
		{
			content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 7.4296875 9.5 L 5.9296875 11 L 12 17.070312 L 18.070312 11 L 16.570312 9.5 L 12 14.070312 L 7.4296875 9.5 z'></path></svg>")
		}

		.header-transparent-dark:not(.header-sticky-scroll) .site-header .main-navigation-flyout > ul > li:not(.mega-menu) ul li.menu-item-has-children > a:after
		{
			content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 10 5.9296875 L 8.5 7.4296875 L 13.070312 12 L 8.5 16.570312 L 10 18.070312 L 16.070312 12 L 10 5.9296875 z'></path></svg>")
		}

		.header-transparent-dark:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button .tools_button_icon.shopping-cart-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 4.4140625 1.9960938 L 1.0039062 2.0136719 L 1.0136719 4.0136719 L 3.0839844 4.0039062 L 6.3789062 11.908203 L 5.1816406 13.824219 C 4.7816406 14.464219 4.7609531 15.272641 5.1269531 15.931641 C 5.4929531 16.590641 6.1874063 17 6.9414062 17 L 19 17 L 19 15 L 6.9414062 15 L 6.8769531 14.882812 L 8.0527344 13 L 15.521484 13 C 16.248484 13 16.917531 12.604703 17.269531 11.970703 L 20.873047 5.4863281 C 21.046047 5.1763281 21.041328 4.7981875 20.861328 4.4921875 C 20.681328 4.1871875 20.352047 4 19.998047 4 L 5.25 4 L 4.4140625 1.9960938 z M 6.0820312 6 L 18.298828 6 L 15.521484 11 L 8.1660156 11 L 6.0820312 6 z M 7 18 A 2 2 0 0 0 5 20 A 2 2 0 0 0 7 22 A 2 2 0 0 0 9 20 A 2 2 0 0 0 7 18 z M 17 18 A 2 2 0 0 0 15 20 A 2 2 0 0 0 17 22 A 2 2 0 0 0 19 20 A 2 2 0 0 0 17 18 z'></path></svg>")
		}

		.header-transparent-dark:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button .tools_button_icon.search-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z'></path></svg>")
		}

		.header-transparent-dark:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button .tools_button_icon.wishlist-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M16.5,3C13.605,3,12,5.09,12,5.09S10.395,3,7.5,3C4.462,3,2,5.462,2,8.5c0,4.171,4.912,8.213,6.281,9.49 C9.858,19.46,12,21.35,12,21.35s2.142-1.89,3.719-3.36C17.088,16.713,22,12.671,22,8.5C22,5.462,19.538,3,16.5,3z M14.811,16.11 c-0.177,0.16-0.331,0.299-0.456,0.416c-0.751,0.7-1.639,1.503-2.355,2.145c-0.716-0.642-1.605-1.446-2.355-2.145 c-0.126-0.117-0.28-0.257-0.456-0.416C7.769,14.827,4,11.419,4,8.5C4,6.57,5.57,5,7.5,5c1.827,0,2.886,1.275,2.914,1.308L12,8 l1.586-1.692C13.596,6.295,14.673,5,16.5,5C18.43,5,20,6.57,20,8.5C20,11.419,16.231,14.827,14.811,16.11z'></path></svg>")
		}

		.header-transparent-dark:not(.header-sticky-scroll) .site-header .header-wrapper .tools a.tools_button .tools_button_icon.account-icon
		{
			background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 3 C 9.8027056 3 8 4.8027056 8 7 C 8 9.1972944 9.8027056 11 12 11 C 14.197294 11 16 9.1972944 16 7 C 16 4.8027056 14.197294 3 12 3 z M 12 5 C 13.116414 5 14 5.8835859 14 7 C 14 8.1164141 13.116414 9 12 9 C 10.883586 9 10 8.1164141 10 7 C 10 5.8835859 10.883586 5 12 5 z M 12 14 C 10.255047 14 8.1871638 14.409783 6.4492188 15.095703 C 5.5802462 15.438663 4.7946961 15.84605 4.1660156 16.369141 C 3.5373351 16.892231 3 17.599384 3 18.5 L 3 21 L 21 21 L 21 20 L 21 18.5 C 21 17.599384 20.462665 16.892231 19.833984 16.369141 C 19.205304 15.84605 18.419754 15.438663 17.550781 15.095703 C 15.812836 14.409783 13.744953 14 12 14 z M 12 16 C 13.414047 16 15.346055 16.373999 16.818359 16.955078 C 17.554512 17.245618 18.176961 17.591965 18.554688 17.90625 C 18.932412 18.220535 19 18.434616 19 18.5 L 19 19 L 5 19 L 5 18.5 C 5 18.434616 5.0675867 18.220535 5.4453125 17.90625 C 5.8230383 17.591965 6.4454882 17.245618 7.1816406 16.955078 C 8.6539455 16.373999 10.585953 16 12 16 z'></path></svg>")
		}

		.header-transparent-dark:not(.header-sticky-scroll) .site-header .header-wrapper .tools ul li a.tools_button .shopping_bag_items_number,
		.header-transparent-dark:not(.header-sticky-scroll) .site-header .header-wrapper .tools ul li a.tools_button .wishlist_items_number
		{
			background-color: #000;
			color: #fff;
		}
	
			
	.site-header .header-wrapper,
	.myaccount-dropdown
	{
		height: 75px;
	}

	.site-content,
	.header-transparent .shop-page-category-description
	{
		padding-top: 75px;
	}

	body.header-transparent.tax-product_cat .site-content .shop-page-category-description.no-padding
	{
		padding-top: 75px;
	}

	.site-header,
	.site-header-mobiles
	{
		background-color: #23282d;
	}

	.site-header-mobiles .header-wrapper-mobiles .tools ul li .tools_button .tools_button_icon.shopping-cart-icon
	{
		background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 4.4140625 1.9960938 L 1.0039062 2.0136719 L 1.0136719 4.0136719 L 3.0839844 4.0039062 L 6.3789062 11.908203 L 5.1816406 13.824219 C 4.7816406 14.464219 4.7609531 15.272641 5.1269531 15.931641 C 5.4929531 16.590641 6.1874063 17 6.9414062 17 L 19 17 L 19 15 L 6.9414062 15 L 6.8769531 14.882812 L 8.0527344 13 L 15.521484 13 C 16.248484 13 16.917531 12.604703 17.269531 11.970703 L 20.873047 5.4863281 C 21.046047 5.1763281 21.041328 4.7981875 20.861328 4.4921875 C 20.681328 4.1871875 20.352047 4 19.998047 4 L 5.25 4 L 4.4140625 1.9960938 z M 6.0820312 6 L 18.298828 6 L 15.521484 11 L 8.1660156 11 L 6.0820312 6 z M 7 18 A 2 2 0 0 0 5 20 A 2 2 0 0 0 7 22 A 2 2 0 0 0 9 20 A 2 2 0 0 0 7 18 z M 17 18 A 2 2 0 0 0 15 20 A 2 2 0 0 0 17 22 A 2 2 0 0 0 19 20 A 2 2 0 0 0 17 18 z'></path></svg>");
	}

	.site-header-mobiles .header-wrapper-mobiles .tools ul li .tools_button .tools_button_icon.search-icon
	{
		background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z'></path></svg>");
	}

	.site-header-mobiles .header-wrapper-mobiles .tools ul li .tools_button .tools_button_icon.wishlist-icon
	{
		background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M16.5,3C13.605,3,12,5.09,12,5.09S10.395,3,7.5,3C4.462,3,2,5.462,2,8.5c0,4.171,4.912,8.213,6.281,9.49 C9.858,19.46,12,21.35,12,21.35s2.142-1.89,3.719-3.36C17.088,16.713,22,12.671,22,8.5C22,5.462,19.538,3,16.5,3z M14.811,16.11 c-0.177,0.16-0.331,0.299-0.456,0.416c-0.751,0.7-1.639,1.503-2.355,2.145c-0.716-0.642-1.605-1.446-2.355-2.145 c-0.126-0.117-0.28-0.257-0.456-0.416C7.769,14.827,4,11.419,4,8.5C4,6.57,5.57,5,7.5,5c1.827,0,2.886,1.275,2.914,1.308L12,8 l1.586-1.692C13.596,6.295,14.673,5,16.5,5C18.43,5,20,6.57,20,8.5C20,11.419,16.231,14.827,14.811,16.11z'></path></svg>");
	}

	.site-header-mobiles .header-wrapper-mobiles .nav ul li .tools_button .tools_button_icon.hamburger-menu-icon
	{
		background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 2 5 L 2 7 L 22 7 L 22 5 L 2 5 z M 2 11 L 2 13 L 22 13 L 22 11 L 2 11 z M 2 17 L 2 19 L 22 19 L 22 17 L 2 17 z'></path></svg>");
	}

	.site-header-mobiles .header-wrapper-mobiles .tools ul li .tools_button .shopping_bag_items_number,
	.site-header-mobiles .header-wrapper-mobiles .tools ul li .tools_button .wishlist_items_number
	{
		background-color: #fff;
	}

	.site-header,
	.site-header-mobiles
	{
		font-size: 14px;
	}

	.site-header .header-wrapper .site-branding .site-logo img
	{
		height: 49px;
	}

	.site-header-mobiles .header-wrapper-mobiles .site-branding .site-logo img
	{
		height: 55px;
	}


	.site-footer,
	.footer-widget-wrapper {
		background-color: #000;
	}

	.site-footer,
	.site-footer .footer-wrapper .footer-socials .shortcode_socials ul li a,
	.site-footer .footer-wrapper .footer-navigation ul li a,
	.footer-widget-wrapper ul.footer-widget-area *,
	.footer-widget-wrapper .widget-area .widget-title
	{
		color: #fff;
	}

	.site-footer .footer-wrapper .footer-socials .shortcode_socials ul li a svg
	{
		fill: #fff;
	}

	.footer-widget-wrapper ul.footer-widget-area li > a:before,
	.footer-widget-wrapper ul.footer-widget-area li a:hover,
	.footer-widget-wrapper ul.footer-widget-area li span.count
	{
		color: rgba(255,255,255, 0.35)!important;
	}


	h1, h2, h3, h4, h5, h6,
	button,
	.button,
	input[type="submit"],
	.vc_btn3,
	.shortcode_getbowtied_slider .swiper-slide .button,
	.shortcode_title.secondary_font,
	.site-header,
	.site-header-mobiles,
	.footer-navigation,
	.widget-area,
	#reply-title,
	.woocommerce-cart .woocommerce,
	.woocommerce-checkout .woocommerce,
	.woocommerce-order-received .woocommerce>p:first-child,
	.woocommerce-error,
	.woocommerce-message,
	.woocommerce ul.products li.product .shop_product_price,
	.woocommerce ul.products li.product .product_thumbnail .shop_product_buttons_wrapper .shop_product_buttons .button,
	.woocommerce .shop-product-badges .onsale,
	.woocommerce .shop-product-badges .out_of_stock,
	.offcanvas_quickview .product_infos .product-badges .onsale,
	.offcanvas_quickview .product_infos .product-badges .out_of_stock,
	.woocommerce-account .woocommerce table a,
	.woocommerce-account .woocommerce table .amount,
	.woocommerce-account .woocommerce .addresses a,
	.woocommerce-edit-address .woocommerce,
	.woocommerce-edit-account .woocommerce,
	#customer_login,
	.shop_table thead th span,
	.woocommerce .shop-page-title-wrapper .shop-sort-wrapper,
	.offcanvas_quickview,
	.screen_btn,
	.offcanvas_minicart,
	.offcanvas_minicart a,
	.offcanvas_minicart span,
	.woocommerce .woocommerce-pagination,
	.posts-navigation .nav-links,
	.getbowtied_ajax_load_button,
	.getbowtied_ajax_load_more_loader,
	.getbowtied_blog_ajax_load_button,
	.getbowtied_blog_ajax_load_more_loader,
	.woocommerce-no-products,
	div.search-no-results,
	div.search-no-results p,
	section.error-404 .icon-404,
	section.error-404,
	button.vc_general,
	.vc_tta-panel-heading h4,
	.vc_tta-panel-heading h4 a, 
	.vc_toggle_title h4,
	.vc_tta-tab a,
	.vc_separator h4,
	.myaccount-dropdown,
	.woocommerce .product_infos .product_price .price,
	.woocommerce-breadcrumb,
	.woocommerce .product_content_wrapper .product_infos .after_single_product_summary,
	.woocommerce.add_to_cart_inline,
	.primary_font,
	.woocommerce .product_infos .cart .quantity,
	.woocommerce .woocommerce-tabs ul.tabs li,
	.shop_attributes th,
	.comment_container .meta,
	.comment-form,
	.variations_form,
	.woocommerce .group_table,
	.product-badges,
	.product_price .onsale,
	.out_of_stock,
	.shortcode_products,
	form.track_order,
	.add_to_cart_inline,
	.woocommerce-account .woocommerce .myaccount_user,
	.woocommerce-account .woocommerce .shop_table td.order-status,
	.woocommerce-account .woocommerce form,
	.woocommerce-account .woocommerce .order-info,
	.woocommerce-view-order .woocommerce table.shop_table,
	.woocommerce-order-received .woocommerce table.shop_table th,
	.site-header .site-title a,
	.site-header-mobiles .site-title a,
	form.track_order p.form-row,
	.shop_table td:before,
	ul.list_categories,
	.blog .sticky-title,
	.blog .entry-meta,
	.search article .entry-meta,
	.archive .sticky-title,
	.archive .entry-meta,
	.single .post-categories li a,
	.single .entry-meta,
	.single .entry-footer .tags-links,
	.navigation_between_posts,
	.posts-navigation a,
	#comments .comment-metadata,
	#comments .comment-reply, #comments .comment-edit-link, #comments .comments-number,
	.shortcode_blog_posts_date,
	.comment-list .pingback,
	figcaption,
	ul.mobile-categories,
	.woocommerce .shop-page-header .shop-page-title-wrapper ul.shop-tools > li .shop-result-count p,
	.woocommerce .product_infos .product_ratings .woocommerce-review-link,
	.woocommerce .product_infos .product_sale_badge .onsale,
	.offcanvas_navigation,
	.woocommerce-MyAccount-navigation,
	.woocommerce-account .woocommerce .woocommerce-MyAccount-content p:first-child,
	.woocommerce .product_infos .stock,
	.footer-copyright,
	.woocommerce #yith-wcwl-popup-message #yith-wcwl-message,
	.woocommerce .product_infos .yith-wcwl-add-to-wishlist a,
	.woocommerce #yith-wcwl-form .wishlist_table .product-name,
	.woocommerce #yith-wcwl-form .wishlist_table .product-stock-status .wishlist-in-stock,
	.woocommerce #yith-wcwl-form .wishlist_table .product-stock-status .wishlist-out-of-stock,
	.woocommerce #yith-wcwl-form .wishlist_table .product-price,
	body.blog:not(.woocommerce) .blog_layout_1 .read_more, body.archive:not(.woocommerce) .blog_layout_1 .read_more,
	body.blog:not(.woocommerce) .blog_layout_2 .read_more, body.archive:not(.woocommerce) .blog_layout_2 .read_more,
	body.blog:not(.woocommerce) .blog_layout_2 .sticky_post_container .sticky_meta > a,
	body.archive:not(.woocommerce) .blog_layout_2 .sticky_post_container .sticky_meta > a,
	body.archive:not(.woocommerce) .blog_layout_1 .sticky_post_container .sticky_meta > a,
	body.blog:not(.woocommerce) .blog_layout_1 .post-categories li a, body.archive:not(.woocommerce) .blog_layout_1 .post-categories li a,
	body.blog:not(.woocommerce) .blog_layout_2 .post-categories li a, body.archive:not(.woocommerce) .blog_layout_2 .post-categories li a,
	body.blog:not(.woocommerce) .blog_layout_1 .sticky_post_container .sticky_meta > a, 
	body.archive:not(.woocommerce) .blog_layout_1 .sticky_post_container .sticky_meta > a,
	.hover-me-nice,
	.woocommerce-checkout.woocommerce-order-pay .woocommerce .order_details li,
	.woocommerce-privacy-policy-link,
	.woocommerce-checkout:not(.woocommerce-order-received).woocommerce-order-pay .woocommerce > .woocommerce-info,
	.woocommerce-order-pay:not(.logged-in) .woocommerce label,
	.wp-block-latest-posts li a,
	.wp-block-button a,
	.wp-block-button__link,
	.wp-block-file .wp-block-file__button,
	.wp-block-cover .wp-block-cover-text,
	.gbt_18_mc_posts_grid .gbt_18_mc_posts_grid_title,
	.gbt_18_mc_editor_posts_grid_title,
	.gbt_18_mc_posts_slider .gbt_18_mc_posts_slider_item_date,
	.gbt_18_mc_posts_slider .gbt_18_mc_posts_slider_item_title,
	.gbt_18_mc_editor_posts_slider_item_title,
	.wp-block-quote p,
	.wp-block-pullquote p,
	.wp-block-quote cite,
	.wp-block-pullquote cite,
	p.has-drop-cap::first-letter,
	.wc-block-grid__product-title,
	.wc-block-grid__product-price,
	.wc-block-grid__product-onsale,
	.wc-block-grid__product-add-to-cart
	{
		font-family: "arcamajora", sans-serif;
	}

	body,
	.shortcode_title.main_font,
	.woocommerce-order-received .woocommerce table.customer_details,
	.woocommerce-account .woocommerce table.customer_details td,
	.woocommerce-order-received .woocommerce .col2-set,
	.woocommerce-order-received .woocommerce p,
	.woocommerce-account .woocommerce,
	.offcanvas_quickview .product_excerpt,
	.secondary_font,
	.comment_container .description p,
	#review_form textarea,
	.shop_attributes td,
	#tab-description p,
	.woocommerce-variation-description,
	.widget-area .widget.widget_rss div.rssSummary,
	address,
	form.track_order p,
	.checkout-info form.login p:first-child,
	.widget-area .widget.widget_text,
	.woocommerce .checkout .checkout-col-aside .payment_methods .payment_box p,
	.woocommerce #order_review .checkout-col-aside .payment_methods .payment_box p,
	.shortcode_products .category_item .category_name .category_desc,
	.woocommerce #order_review .checkout-col-aside .woocommerce-terms-and-conditions p, .woocommerce .checkout .checkout-col-aside .woocommerce-terms-and-conditions p,
	.woocommerce-account form.lost_reset_password p.form-row .woocommerce-password-hint,
	.woocommerce-account form.lost_reset_password p.form-row .woocommerce-password-strength,
	.woocommerce-checkout .woocommerce .woocommerce-terms-and-conditions-wrapper .woocommerce-privacy-policy-text p,
	.woocommerce-account .woocommerce .woocommerce-MyAccount-content .woocommerce-Payment .payment_box p
	{ 
		font-family: "radnika", sans-serif;
	}

			
	body,
	abbr,
	acronym,
	h1, h2, h3, h4, h5, h6,
	a,
	.widget-area .widget.widget_rss cite,
	.widget-area h4,
	.woocommerce-cart .woocommerce .cart-collaterals .cart_totals table th,
	.woocommerce-cart .woocommerce form table tbody td.product-name a,
	.woocommerce-cart .woocommerce form table tbody td.actions .button,
	.woocommerce-cart .woocommerce form table tbody td.product-subtotal .remove,
	.blog .entry-title a, .archive .entry-title a,
	.woocommerce .woocommerce-tabs ul.tabs li.active a,
	.woocommerce .products .yith-wcwl-add-to-wishlist a:hover,
	.woocommerce-account .woocommerce td.order-actions .view,
	.woocommerce-order-received .woocommerce ul.order_details li>strong,
	.woocommerce-order-received .woocommerce>p:first-child,
	.woocommerce-order-received .woocommerce table.shop_table tfoot .amount,
	.woocommerce-account .woocommerce #customer_login h2.active,
	.woocommerce .woocommerce-pagination ul.page-numbers a,
	.posts-navigation .nav-links a,
	.woocommerce .product_content_wrapper .product_infos .after_single_product_summary .product_meta_wrapper span span,
	.shop_attributes th,
	.woocommerce .group_table,
	.woocommerce.add_to_cart_inline .amount,
	.woocommerce .woocommerce-shipping-fields h3#ship-to-different-address label,
	.woocommerce table.shop_table.customer_details th,
	.woocommerce table.shop_table tfoot tr:last-child .amount,
	.comments_section label,
	.comments_section a.user, .comments_section a.logout,
	section.error-404 form:after,
	.woocommerce-cart .entry-content .woocommerce form table tbody td.product-name a,
	.woocommerce .cart .quantity input.qty,
	.woocommerce-cart .entry-content .woocommerce form table tbody td.actions .button,
	input[type="text"],
	.woocommerce-cart .entry-content .woocommerce .cart-collaterals .cart_totals,
	.cart_totals label,
	.woocommerce label,
	.woocommerce-info,
	.woocommerce table.shop_table th,
	.woocommerce .checkout .checkout-col-aside table.woocommerce-checkout-review-order-table tfoot tr .amount,
	.woocommerce #order_review .checkout-col-aside table.woocommerce-checkout-review-order-table tfoot tr .amount,
	.woocommerce .checkout .checkout-col-aside table.woocommerce-checkout-review-order-table tfoot tr #shipping_method label,
	.woocommerce #order_review .checkout-col-aside table.woocommerce-checkout-review-order-table tfoot tr #shipping_method label,
	.woocommerce ul.products li.product .shop_product_metas h3 a,
	.woocommerce ul.products li.product .product_thumbnail .shop_product_buttons_wrapper .shop_product_buttons .button,
	.woocommerce .cart .quantity input.qty,
	.widget-area .widget.woocommerce.widget_price_filter .price_slider_amount .button,
	.widget-area .widget.woocommerce.widget_product_categories ul li>a:hover,
	.widget-area .widget.woocommerce.widget_layered_nav ul li>a:hover,
	.widget-area .widget.woocommerce.widget_product_categories ul li>a:hover~span.count, 
	.widget-area .widget.woocommerce.widget_product_categories ul li>a:hover~span.post_count,
	.widget-area .widget.woocommerce.widget_layered_nav ul li>a:hover~span.count, 
	.widget-area .widget.woocommerce.widget_layered_nav ul li>a:hover~span.post_count,
	.widget-area .widget.widget_archive ul li>a:hover,
	.site-header .header-wrapper .tools .myaccount-dropdown ul>li>a,
	select,
	.archive:not(.woocommerce) .blog_layout_1 .blog-header-wrapper h1.blog-header, 
	.blog:not(.woocommerce) .blog_layout_1 .blog-header-wrapper h1.blog-header,
	.archive:not(.woocommerce) .blog_layout_1 .blog-header-wrapper .list_categories li a:hover, 
	.blog:not(.woocommerce) .blog_layout_1 .blog-header-wrapper .list_categories li a:hover,
	.archive:not(.woocommerce) .blog_layout_1 .blog-header-wrapper .list_categories li.current-cat a, 
	.blog:not(.woocommerce) .blog_layout_1 .blog-header-wrapper .list_categories li.current-cat a,
	body.archive:not(.woocommerce) .blog_layout_default h1.blog-header, 
	body.blog:not(.woocommerce) .blog_layout_default h1.blog-header,
	body.archive:not(.woocommerce) .blog_layout_default ul.list_categories li.current-cat a, 
	body.blog:not(.woocommerce) .blog_layout_default ul.list_categories li.current-cat a,
	body.archive:not(.woocommerce) .blog_layout_2 .blog-header-wrapper .list_categories li.current-cat a, 
	body.blog:not(.woocommerce) .blog_layout_2 .blog-header-wrapper .list_categories li.current-cat a,
	body.archive:not(.woocommerce) .blog_layout_2 .read_more, body.blog:not(.woocommerce) .blog_layout_2 .read_more,
	body.archive:not(.woocommerce) .blog_layout_2 .blog-header-wrapper .list_categories li a:hover, 
	body.blog:not(.woocommerce) .blog_layout_2 .blog-header-wrapper .list_categories li a:hover,
	body.archive:not(.woocommerce) .blog_layout_default ul.list_categories li a:hover, 
	body.blog:not(.woocommerce) .blog_layout_default ul.list_categories li a:hover,
	body.archive:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links .page-numbers, 
	body.blog:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links .page-numbers,
	body.archive:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links .page-numbers, 
	body.blog:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links .page-numbers,
	input[type=color], input[type=date], input[type=datetime], input[type=datetime-local], input[type=email], input[type=month], 
	input[type=number], input[type=password], input[type=tel], input[type=text], input[type=time], input[type=url], 
	input[type=week], textarea,
	.woocommerce-customer-details .woocommerce-column address,
	.woocommerce-customer-details .woocommerce-column .woocommerce-customer-details--phone,
	.woocommerce-customer-details .woocommerce-column .woocommerce-customer-details--email,
	.woocommerce-account .woocommerce #customer_login label[for=rememberme],
	.woocommerce-account .woocommerce .woocommerce-MyAccount-content>p:first-child a,
	.woocommerce-account .woocommerce .addresses address,
	.vc_tta-color-white.vc_tta-style-flat .vc_tta-tab.vc_active>a,
	.woocommerce .product_infos .yith-wcwl-add-to-wishlist a,
	.comments_section ul li article .comment-text .comment-edit-link, 
	.comments_section ul li article .comment-text .comment-reply,
	.woocommerce-checkout:not(.woocommerce-order-received) .select2-container--default .select2-selection--single .select2-selection__rendered,
	.woocommerce-cart .entry-content .woocommerce form table tbody td.product-subtotal .remove,
	.woocommerce-cart .entry-content .woocommerce .cart-collaterals .cart_totals table th,
	.woocommerce-cart .entry-content .woocommerce .cart-collaterals .cross-sells li.product .shop_product_buttons_wrapper .shop_product_buttons a.button:before,
	.categories_layout_default .woocommerce .shortcode_products li.category_item .category_name a,
	.shortcode_title,
	.autocomplete-suggestion .autocomplete-suggestion-info,
	.woocommerce-account .woocommerce table.my_account_orders .woocommerce-orders-table__cell-order-actions .button,
	.woocommerce-checkout.woocommerce-order-pay .order_details li strong,
	.wc-block-grid__product-add-to-cart
	{
		color: #000;
	}

	button,
	.button,
	input[type="submit"],
	.widget-area .widget.woocommerce.widget_product_tag_cloud a:hover,
	.widget-area .widget.widget_tag_cloud a:hover,
	.woocommerce-cart .woocommerce .cart-collaterals .cart_totals .wc-proceed-to-checkout a:hover,
	.woocommerce .checkout .checkout-col-aside #place_order:hover,
	.woocommerce #order_review .checkout-col-aside #place_order:hover,
	.main-navigation-flyout > ul > li > ul,
	.entry-content .mejs-container .mejs-controls .mejs-time-rail .mejs-time-current,
	.woocommerce .woocommerce-pagination ul.page-numbers a:hover,
	.posts-navigation .nav-links a:hover,
	.woocommerce.add_to_cart_inline a.add_to_cart_button,
	.screen_btn,
	.woocommerce-cart .entry-content .woocommerce .cart-collaterals .cart_totals .wc-proceed-to-checkout a,
	.woocommerce-cart .woocommerce .cart-collaterals .cart_totals .wc-proceed-to-checkout a,
	.woocommerce .checkout .checkout-col-aside #place_order,
	.woocommerce #order_review .checkout-col-aside #place_order,
	.offcanvas_quickview .product-images-wrapper .quickview-pagination .swiper-pagination-bullet-active,
	.widget-area .widget.woocommerce.widget_price_filter .ui-slider .ui-slider-range,
	body.archive:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links a:hover, 
	body.blog:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links a:hover,
	body.archive:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links a:hover, 
	body.blog:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links a:hover
	{
		background-color: #000;
	}

	.myaccount-popup,
	.search_wrapper
	{
		box-shadow: 0px 10px 80px -25px rgba(0,0,0, 0.1);
	}

	.woocommerce-account .woocommerce #customer_login h2.active
	{
		border-color: #000;
	}

	.offcanvas_quickview .product-images-wrapper .fade-gradient
	{
		background: -moz-linear-gradient(top,  rgba(255,255,255,0) 0%, #fff 70%);
		background: -webkit-linear-gradient(top,  rgba(255,255,255,0) 0%, #fff 70%);
		background: linear-gradient(to bottom,  rgba(255,255,255,0) 0%, #fff 70%);
	}

	body.offcanvas_open .offcanvas_overlay:after
	{
		box-shadow: inset 0px 0px 40px -10px #000;
		opacity: 0.7;
	}

	.site-header .header-wrapper .tools .myaccount-dropdown:hover>ul,
	.autocomplete-suggestions
	{
		box-shadow: 0px 11px 15px 0px rgba(0,0,0, 0.1);
	}

	.woocommerce.archive .shop-sidebar,
	.comments_section,
	input[type=color], input[type=date], input[type=datetime], input[type=datetime-local],
	input[type=email], input[type=month], input[type=number], input[type=password], input[type=search], 
	input[type=tel], input[type=text], input[type=time], input[type=url], input[type=week], textarea,
	.woocommerce-checkout .select2-container--default .select2-selection--single
	{
		background: rgba(0,0,0, 0.05);
	}

	input[type=color]:focus, input[type=date]:focus, input[type=datetime]:focus, input[type=datetime-local]:focus,
	input[type=email]:focus, input[type=month]:focus, input[type=number]:focus, input[type=password]:focus, input[type=search]:focus, 
	input[type=tel]:focus, input[type=text]:focus, input[type=time]:focus, input[type=url]:focus, input[type=week]:focus, textarea:focus,
	input[type=color]:hover, input[type=date]:hover, input[type=datetime]:hover, input[type=datetime-local]:hover,
	input[type=email]:hover, input[type=month]:hover, input[type=number]:hover, input[type=password]:hover, input[type=search]:hover, 
	input[type=tel]:hover, input[type=text]:hover, input[type=time]:hover, input[type=url]:hover, input[type=week]:hover, textarea:hover
	{
		background: rgba(0,0,0, 0.1);
	}

	.woocommerce .cart .quantity input.qty
	{
		border-bottom: 2px solid #000;
	}

	.woocommerce ul.products li.product .product_thumbnail .shop_product_buttons_wrapper .shop_product_buttons
	{
		border-color: rgba(0,0,0, 0.05);
	}

	.woocommerce-account .woocommerce table thead tr
	{
		border-bottom: 2px solid rgba(0,0,0, 0.05);
	}

	.widget-area .widget.woocommerce.widget_price_filter .ui-slider .ui-slider-handle
	{
		border: 3px solid #000;
	}

	.site-header .header-wrapper .tools .myaccount-dropdown ul>li>a
	{
		border-top: 1px solid rgba(0,0,0, 0.1);
	}

	.comments_section ul li
	{
		border-top: 1px solid rgba(0,0,0, 0.05);
	}

	.comments_section ul.comment-list>li:last-child
	{
		border-bottom: 1px solid rgba(0,0,0, 0.05);
	}

	.search_wrapper .search-widget-area li.widget
	{
		    border-right: 1px solid rgba(0,0,0, 0.1);
	}

	table tr
	{
		border-bottom: 1px solid rgba(0,0,0, 0.05);
	}

	.offcanvas_minicart ul.cart_list li,
	.search_wrapper .getbowtied_search_bar .search-field
	{
		border-bottom: 1px solid rgba(0,0,0, 0.1);
	}

	.comments_section .comments-number svg
	{
		fill: #000;
	}

	body.archive:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links, 
	body.blog:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links,
	body.archive:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links, 
	body.blog:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links,
	body.archive:not(.woocommerce) .blog_layout_default .posts-navigation .nav-links, 
	body.blog:not(.woocommerce) .blog_layout_default .posts-navigation .nav-links
	{
		border-top-color: rgba(0,0,0, 0.35);
	}

	body.archive:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links .page-numbers, 
	body.blog:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links .page-numbers,
	body.archive:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links .page-numbers, 
	body.blog:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links .page-numbers,
	body.archive:not(.woocommerce) .blog_layout_default .posts-navigation .nav-links .page-numbers, 
	body.blog:not(.woocommerce) .blog_layout_default .posts-navigation .nav-links .page-numbers
	{
		border-right-color: rgba(0,0,0, 0.35);
	}

	button,
	.button,
	input[type="submit"],
	button:hover,
	button:focus,
	.button:hover,
	.button:focus,
	button.disabled:hover,
	button.disabled:focus,
	button[disabled]:hover,
	button[disabled]:focus,
	.button.disabled:hover,
	.button.disabled:focus,
	.button[disabled]:hover,
	.button[disabled]:focus,
	input[type="submit"]:hover,
	input[type="submit"]:focus,
	.woocommerce .woocommerce-pagination ul.page-numbers a:hover,
	.posts-navigation .nav-links a:hover,
	.woocommerce-account.woocommerce-downloads .woocommerce-Button,
	.footer-copyright a,
	body.archive:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links a:hover, 
	body.blog:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links a:hover,
	body.archive:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links a:hover, 
	body.blog:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links a:hover,
	.add_to_cart_inline .add_to_cart_button,
	.add_to_cart_inline .add_to_cart_button:focus, 
	.add_to_cart_inline .add_to_cart_button:hover
	{
		color: #fff;
	}

	.woocommerce-account .woocommerce .woocommerce-MyAccount-navigation ul li a:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 2 C 6.4889971 2 2 6.4889971 2 12 C 2 17.511003 6.4889971 22 12 22 C 17.511003 22 22 17.511003 22 12 C 22 6.4889971 17.511003 2 12 2 z M 12 4 C 16.430123 4 20 7.5698774 20 12 C 20 16.430123 16.430123 20 12 20 C 7.5698774 20 4 16.430123 4 12 C 4 7.5698774 7.5698774 4 12 4 z'></path></svg>");
	}

	.woocommerce-account .woocommerce .woocommerce-MyAccount-navigation ul li a:hover:before,
	.woocommerce-account .woocommerce .woocommerce-MyAccount-navigation ul li.is-active a:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 2 A 10 10 0 0 0 2 12 A 10 10 0 0 0 12 22 A 10 10 0 0 0 22 12 A 10 10 0 0 0 12 2 z'></path></svg>");
	}


	.woocommerce-cart .woocommerce form table tbody td,
	table.shop_table th,
	table.shop_table tfoot th,
	.checkout-info form.login p:first-child,
	.widget-area .widget.widget_rss div.rssSummary,
	.woocommerce .woocommerce-tabs #reviews #comments .description p,
	.shop_attributes td,
	label,
	.comments_section ul li article .comment-metadata time,
	.woocommerce-cart .entry-content .woocommerce form table tbody td,
	.woocommerce .checkout .checkout-col-aside table.woocommerce-checkout-review-order-table tbody .cart_item .product-total .amount,
	.woocommerce #order_review .checkout-col-aside table.woocommerce-checkout-review-order-table tbody .cart_item .product-total .amount,
	.woocommerce table.shop_table td.product-name .product-quantity,
	.woocommerce .checkout .checkout-col-aside .payment_methods>li .payment_box p,
	.woocommerce #order_review .checkout-col-aside .payment_methods>li .payment_box p,
	.woocommerce.add_to_cart_inline del,
	.woocommerce.add_to_cart_inline del span.amount,
	.woocommerce .product_infos .product_excerpt p,
	.woocommerce .product_infos .product_excerpt,
	body.archive:not(.woocommerce) .blog_layout_default .sticky-post .sticky-title .title a:hover, 
	body.blog:not(.woocommerce) .blog_layout_default .sticky-post .sticky-title .title a:hover,
	body.archive:not(.woocommerce) .blog_layout_2 .read_more, body.blog:not(.woocommerce) .blog_layout_2 .read_more:hover,
	body.archive:not(.woocommerce) .blog_layout_1 .post-categories li a, 
	body.blog:not(.woocommerce) .blog_layout_1 .post-categories li a,
	body.archive:not(.woocommerce) .blog_layout_2 .post-categories li a, 
	body.blog:not(.woocommerce) .blog_layout_2 .post-categories li a,
	body.archive:not(.woocommerce) .blog_layout_3 .post-categories li a, 
	body.blog:not(.woocommerce) .blog_layout_3 .post-categories li a,
	.woocommerce .product_infos .yith-wcwl-add-to-wishlist a:hover,
	.comments_section ul li article .comment-text .comment-edit-link:hover, 
	.comments_section ul li article .comment-text .comment-reply .comment-reply-link:hover,
	.woocommerce #order_review .checkout-col-aside .woocommerce-terms-and-conditions p, .woocommerce .checkout .checkout-col-aside .woocommerce-terms-and-conditions p,
	.wcppec-checkout-buttons__separator,
	.woocommerce-checkout .woocommerce .woocommerce-terms-and-conditions-wrapper .woocommerce-privacy-policy-text p,
	.woocommerce-account .woocommerce .woocommerce-MyAccount-content .woocommerce-Payment .payment_box p
	{
		color: rgba(0,0,0, 0.6);
	}

	button:hover,
	button:focus,
	.button:hover,
	.button:focus,
	button.disabled:hover,
	button.disabled:focus,
	button[disabled]:hover,
	button[disabled]:focus,
	.button.disabled:hover,
	.button.disabled:focus,
	.button[disabled]:hover,
	.button[disabled]:focus,
	input[type="submit"]:hover,
	input[type="submit"]:focus,
	.screen_btn#view_details_screen
	{
		background-color: rgba(0,0,0, 0.6);
	}


	.widget-area .amount, .widget-area .reviewer,
	.widget-area .widget.woocommerce.widget_shopping_cart li .quantity,
	.widget-area .widget.woocommerce.widget_products li del,
	.widget-area .widget.woocommerce.widget_products li ins,
	.woocommerce-cart .woocommerce form table tbody td.product-name a:hover,
	.woocommerce .variation dd p,
	.woocommerce-cart .woocommerce form table tbody td.product-subtotal .remove:hover,
	.woocommerce-account .woocommerce td.order-actions a.button:hover,
	.woocommerce-order-received .woocommerce ul.order_details li,
	.woocommerce-order-received .woocommerce p,
	.woocommerce-order-received .woocommerce table.shop_table .amount,
	.woocommerce-order-received .woocommerce table.shop_table tfoot td,
	.woocommerce-order-received .woocommerce table.customer_details,
	.woocommerce ul.products li.product h3 a:hover,
	.woocommerce ul.products li.product .shop_product_price,
	.woocommerce .price del,
	.woocommerce .shop-product-badges .out_of_stock,
	.offcanvas_quickview .product_infos .product-badges .out_of_stock,
	.woocommerce .star-rating:before,
	.offcanvas_minicart .quantity,
	.offcanvas_minicart .remove,
	.fixed-container .total strong,
    .woocommerce ul.shop_categories_list li a h3 mark,
    .woocommerce ul.shop_categories_list li a h3:hover,
	.woocommerce ul.shop_categories_with_thumb li a h3 mark,
	.woocommerce ul.shop_categories_with_thumb li a h3:hover,
	.woocommerce .woocommerce-pagination ul.page-numbers .current,
	.blog .posts-navigation .nav-links .current,
	.archive .posts-navigation .nav-links .current,
	.search .posts-navigation .nav-links .current,
	.getbowtied_ajax_load_more_loader,
	.getbowtied_ajax_load_button.finished a,
	.getbowtied_blog_ajax_load_more_loader,
	.getbowtied_blog_ajax_load_button.finished a,
	.widget-area .widget h4,
	.widget-area .widget h4 a,
	.widget-area .widget ul>li>span.count,
	.woocommerce .product_content_wrapper .product_infos .after_single_product_summary .product_meta_wrapper span,
	.woocommerce .product_infos .single_product_share_wrapper .share-product-text,
	.woocommerce .product_infos .single_product_share .share-product-text,
	.track_order:before,
	#reviews #comments h2,
	.comment_container time,
	.woocommerce .comment-form-rating p.stars a:after,
	.woocommerce .product-badges .out_of_stock,
	.out_of_stock,
	.shortcode_products .count,
	address,
	.checkout-info form.login label.inline,
	.blog article .entry-meta,
	.search article .entry-meta,
	.blog .list_categories li a,
	.archive article .entry-meta,
	.archive .list_categories li a,
	.single .post-categories li a,
	.single .entry-meta,
	.single .entry-footer .tags-links a,
	.comment-notes, .comment-notes a,
	.logged-in-as, .logged-in-as a,
	.comment-list .pingback,
	figcaption, figcaption a,
	.woocommerce-account .woocommerce #customer_login h2,
	.woocommerce .woocommerce-tabs ul.tabs li a sup,
	.woocommerce .product_infos .stock.out-of-stock,
	.blog_layout_default .sticky-post .sticky-title span.date,
	.shortcode_products .category_item .category_name .category_desc,
	.widget-area .widget.woocommerce.widget_product_categories ul li>a:before,
	.widget-area .widget.woocommerce.widget_layered_nav ul li>a:before,
	body.archive:not(.woocommerce) .blog_layout_1 .entry-title a:hover, 
	body.blog:not(.woocommerce) .blog_layout_1 .entry-title a:hover,
	body.archive:not(.woocommerce) .blog_layout_2 .entry-title a:hover, 
	body.blog:not(.woocommerce) .blog_layout_2 .entry-title a:hover,
	body.archive:not(.woocommerce) .blog_layout_1 .read_more:hover, 
	body.blog:not(.woocommerce) .blog_layout_1 .read_more:hover,
	.widget-area .widget.widget_archive ul li>a:before,
	body.archive:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links .current, 
	body.blog:not(.woocommerce) .blog_layout_2 .posts-navigation .nav-links .current,
	body.archive:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links .current, 
	body.blog:not(.woocommerce) .blog_layout_1 .posts-navigation .nav-links .current,
	.offcanvas_aside .offcanvas_close p,
	.woocommerce table.shop_table .wc-item-meta li p,
	.woocommerce-checkout.woocommerce-order-pay .order_details li,
	.wc-block-grid__product-price
	{
		color: rgba(0,0,0, 0.35);
	}

	.woocommerce .variation dd,
	.woocommerce .shop-product-badges .out_of_stock,
	.offcanvas_quickview .product_infos .product-badges .out_of_stock,
	.woocommerce .product-badges .out_of_stock,
	.out_of_stock,
	.woocommerce-account .woocommerce #customer_login h2,
	.single .entry-footer .tags-links a,
	.woocommerce .product_infos .stock.out-of-stock
	{
		border-color: rgba(0,0,0, 0.35);
	}

	button.disabled,
	button[disabled],
	.button.disabled,
	.button[disabled],
	{
		background-color: rgba(0,0,0, 0.35);
	}


	.woocommerce-cart .woocommerce form table tbody td.actions .button,
	.woocommerce-order-received .woocommerce header h2,
	.woocommerce .woocommerce-pagination ul.page-numbers,
	.woocommerce .woocommerce-pagination ul.page-numbers a,
	.woocommerce .woocommerce-pagination ul.page-numbers .current,
	.widget-area .widget,
	.widget-area .widget.woocommerce.widget_product_search form input.search-field,
	.widget-area .widget.widget_search form input.search-field,
	.select2-container.select2-container--default .select2-selection--multiple,
	.select2-container.select2-container--default .select2-selection--single,
	.offcanvas_close,
	.woocommerce .cart .quantity input.qty,
	.woocommerce .product_content_wrapper .product_infos .after_single_product_summary,
	.woocommerce-cart .entry-content .woocommerce form table tbody td.actions .button
	{
		border-color: rgba(0,0,0, 0.1);
	}

	section.error-404 > .page-content > p:before,
	.woocommerce .empty-cart:before,
	section.no-results .sorry-no-results:before
	{
		color: rgba(0,0,0, 0.1);
	}

	.select2-container .select2-choice,
	select:hover
	{
		background-color: rgba(0,0,0, 0.1);
	}


	.woocommerce .checkout .checkout-col-aside,
	.woocommerce #order_review .checkout-col-aside,
	.woocommerce-cart .woocommerce .cart-collaterals,
	.woocommerce .woocommerce_tabs_wrapper,
	.woocommerce-cart .entry-content .woocommerce .cart-collaterals,
	select
	{
		background-color: rgba(0,0,0, 0.05);
	}

	.woocommerce-cart .entry-content .woocommerce .cart-collaterals .cross-sells li.product .shop_product_metas
	{
		background-color: rgba(255,255,255, 0.05);
	}

	.widget-area .widget.woocommerce.widget_product_tag_cloud a:hover,
	.widget-area .widget.widget_tag_cloud a:hover,
	.woocommerce-checkout-review-order-table tr,
	.woocommerce .checkout .checkout-col-aside .payment_methods > li,
	.woocommerce #order_review .checkout-col-aside .payment_methods > li,
	.cart-collaterals tr,
	.woocommerce-account .woocommerce .woocommerce-MyAccount-content .woocommerce-Payment .payment_methods .woocommerce-PaymentMethod
	{
		border-color: rgba(0,0,0, 0.05);
	}


	@media only screen and (max-width: 63.95em) {
		.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-add-button:before,
		.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistaddedbrowse:before,
		.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistexistsbrowse:before
		{
			content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='22' height='22' viewBox='0 0 24 24' fill='rgb(255,199,65)'><path d='M16.256,3.005C13.515,3.117,12,5.09,12,5.09s-1.515-1.973-4.256-2.085C5.906,2.93,4.221,3.845,3.111,5.312 c-3.862,5.104,3.45,11.075,5.17,12.678c1.029,0.959,2.299,2.098,3.057,2.773c0.379,0.338,0.944,0.338,1.323,0 c0.758-0.675,2.028-1.814,3.057-2.773c1.72-1.603,9.033-7.574,5.17-12.678C19.779,3.845,18.094,2.93,16.256,3.005z'></path></svg>");
		}
	}

	.woocommerce form.track_order:before
	{
		background: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='150' height='150' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 8 3 C 5.791 3 4 4.791 4 7 C 4 10 8 14 8 14 C 8 14 12 10 12 7 C 12 4.791 10.209 3 8 3 z M 20 3 A 2 2 0 0 0 18 5 A 2 2 0 0 0 20 7 A 2 2 0 0 0 22 5 A 2 2 0 0 0 20 3 z M 8 5 C 9.105 5 10 5.895 10 7 C 10 8.105 9.105 9 8 9 C 6.895 9 6 8.105 6 7 C 6 5.895 6.895 5 8 5 z M 20 9 A 1 1 0 0 0 19 10 A 1 1 0 0 0 20 11 A 1 1 0 0 0 21 10 A 1 1 0 0 0 20 9 z M 4 13 A 1 1 0 0 0 3 14 A 1 1 0 0 0 4 15 A 1 1 0 0 0 5 14 A 1 1 0 0 0 4 13 z M 12 13 A 1 1 0 0 0 11 14 A 1 1 0 0 0 12 15 A 1 1 0 0 0 13 14 A 1 1 0 0 0 12 13 z M 16 13 A 1 1 0 0 0 15 14 A 1 1 0 0 0 16 15 A 1 1 0 0 0 17 14 A 1 1 0 0 0 16 13 z M 20 13 A 1 1 0 0 0 19 14 A 1 1 0 0 0 20 15 A 1 1 0 0 0 21 14 A 1 1 0 0 0 20 13 z M 4 17 A 2 2 0 0 0 2 19 A 2 2 0 0 0 4 21 A 2 2 0 0 0 6 19 A 2 2 0 0 0 4 17 z'></path></svg>");
	}

	.comments_section .comments-number:after
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='60' height='60' viewBox='0 0 100 100' fill='rgb(0,0,0)'><path d='M50,92c-1.104,0-2-0.896-2-2s0.896-2,2-2c13.533,0,26.143-7.28,32.908-19c6.767-11.72,6.767-26.28,0-38  C76.143,19.28,63.533,12,50,12c-13.533,0-26.143,7.28-32.909,19c-6.766,11.72-6.766,26.28,0,38  c3.444,5.966,1.502,12.072-5.468,17.193c-0.348,0.256-0.491,0.705-0.355,1.117C11.403,87.724,11.785,88,12.218,88H40  c1.104,0,2,0.896,2,2s-0.896,2-2,2H12.218c-2.166,0-4.075-1.383-4.75-3.44c-0.677-2.06,0.042-4.306,1.787-5.589  c7.922-5.821,5.25-10.45,4.373-11.971c-7.479-12.953-7.479-29.047,0-42S35.043,8,50,8c14.958,0,28.895,8.047,36.373,21  s7.479,29.047,0,42S64.958,92,50,92z'></path></svg>");
	}

	.blog_ajax_load_more:before,
	.shop_ajax_load_more:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='22' height='22' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 3 C 7.037 3 3 7.038 3 12 L 5 12 C 5 8.14 8.141 5 12 5 C 14.185097 5 16.125208 6.0167955 17.408203 7.5917969 L 15 10 L 21 10 L 21 4 L 18.833984 6.1660156 C 17.184843 4.2316704 14.736456 3 12 3 z M 19 12 C 19 15.859 15.859 19 12 19 C 9.8149031 19 7.8747922 17.983204 6.5917969 16.408203 L 9 14 L 3 14 L 3 20 L 5.1660156 17.833984 C 6.8151574 19.76833 9.263544 21 12 21 C 16.963 21 21 16.963 21 12 L 19 12 z'></path></svg>");
	}

	.offcanvas_aside .offcanvas_close .offcanvas-close-icon
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 4.7070312 3.2929688 L 3.2929688 4.7070312 L 10.585938 12 L 3.2929688 19.292969 L 4.7070312 20.707031 L 12 13.414062 L 19.292969 20.707031 L 20.707031 19.292969 L 13.414062 12 L 20.707031 4.7070312 L 19.292969 3.2929688 L 12 10.585938 L 4.7070312 3.2929688 z'></path></svg>");
	}

	.woocommerce-no-products:before,
	body.search-no-results .page-content .search-no-results .sorry-no-results::before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z'></path></svg>");
	}

	@media only screen and (min-width: 64em) {
		.woocommerce-no-products:before,
		body.search-no-results .page-content .search-no-results .sorry-no-results::before
		{
			content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='500' height='500' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z'></path></svg>");
		}
	}

	.woocommerce ul.products li.product .product_thumbnail .shop_product_buttons_wrapper .shop_product_buttons .button.product_type_simple:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 4.4140625 1.9960938 L 1.0039062 2.0136719 L 1.0136719 4.0136719 L 3.0839844 4.0039062 L 6.3789062 11.908203 L 5.1816406 13.824219 C 4.7816406 14.464219 4.7609531 15.272641 5.1269531 15.931641 C 5.4929531 16.590641 6.1874063 17 6.9414062 17 L 19 17 L 19 15 L 6.9414062 15 L 6.8769531 14.882812 L 8.0527344 13 L 15.521484 13 C 16.248484 13 16.917531 12.604703 17.269531 11.970703 L 20.873047 5.4863281 C 21.046047 5.1763281 21.041328 4.7981875 20.861328 4.4921875 C 20.681328 4.1871875 20.352047 4 19.998047 4 L 5.25 4 L 4.4140625 1.9960938 z M 6.0820312 6 L 18.298828 6 L 15.521484 11 L 8.1660156 11 L 6.0820312 6 z M 7 18 A 2 2 0 0 0 5 20 A 2 2 0 0 0 7 22 A 2 2 0 0 0 9 20 A 2 2 0 0 0 7 18 z M 17 18 A 2 2 0 0 0 15 20 A 2 2 0 0 0 17 22 A 2 2 0 0 0 19 20 A 2 2 0 0 0 17 18 z'></path></svg>");
	}

	.woocommerce ul.products li.product .product_thumbnail .shop_product_buttons_wrapper .shop_product_buttons .button.product_type_variable:before,
	.woocommerce ul.products li.product .product_thumbnail .shop_product_buttons_wrapper .shop_product_buttons .button.product_type_grouped:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 2 5 L 2 7 L 22 7 L 22 5 L 2 5 z M 2 11 L 2 13 L 22 13 L 22 11 L 2 11 z M 2 17 L 2 19 L 22 19 L 22 17 L 2 17 z'></path></svg>");
	}

	.woocommerce ul.products li.product .product_thumbnail .shop_product_buttons_wrapper .shop_product_buttons .button.product_type_external:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 5 3 C 3.9069372 3 3 3.9069372 3 5 L 3 19 C 3 20.093063 3.9069372 21 5 21 L 19 21 C 20.093063 21 21 20.093063 21 19 L 21 12 L 19 12 L 19 19 L 5 19 L 5 5 L 12 5 L 12 3 L 5 3 z M 14 3 L 14 5 L 17.585938 5 L 8.2929688 14.292969 L 9.7070312 15.707031 L 19 6.4140625 L 19 10 L 21 10 L 21 3 L 14 3 z'></path></svg>");
	}

	.woocommerce ul.products li.product .product_thumbnail .shop_product_buttons_wrapper .shop_product_buttons .button.getbowtied_product_quick_view_button:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 4 C 4 4 1 12 1 12 C 1 12 4 20 12 20 C 20 20 23 12 23 12 C 23 12 20 4 12 4 z M 12 6 C 17.276 6 19.944594 10.267094 20.808594 11.996094 C 19.943594 13.713094 17.255 18 12 18 C 6.724 18 4.0554062 13.732906 3.1914062 12.003906 C 4.0574062 10.286906 6.745 6 12 6 z M 12 8 C 9.791 8 8 9.791 8 12 C 8 14.209 9.791 16 12 16 C 14.209 16 16 14.209 16 12 C 16 9.791 14.209 8 12 8 z M 12 10 C 13.105 10 14 10.895 14 12 C 14 13.105 13.105 14 12 14 C 10.895 14 10 13.105 10 12 C 10 10.895 10.895 10 12 10 z'></path></svg>");
	}

	.single .navigation_between_posts .nav-next > a
	{
		background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='75' height='75' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 10 5.9296875 L 8.5 7.4296875 L 13.070312 12 L 8.5 16.570312 L 10 18.070312 L 16.070312 12 L 10 5.9296875 z'></path></svg>");
	}

	.single .navigation_between_posts .nav-previous > a
	{
		background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='75' height='75' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 13 5.9296875 L 6.9296875 12 L 13 18.070312 L 14.5 16.570312 L 9.9296875 12 L 14.5 7.4296875 L 13 5.9296875 z'></path></svg>");
	}

	body.archive:not(.woocommerce) .posts-navigation .nav-links .next:after,
	body.blog:not(.woocommerce) .posts-navigation .nav-links .next:after,
	.woocommerce .woocommerce-pagination ul.page-numbers .next
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 10 5.9296875 L 8.5 7.4296875 L 13.070312 12 L 8.5 16.570312 L 10 18.070312 L 16.070312 12 L 10 5.9296875 z'></path></svg>");
	}

	body.archive:not(.woocommerce) .posts-navigation .nav-links .prev:after,
	body.blog:not(.woocommerce) .posts-navigation .nav-links .prev:after,
	.woocommerce .woocommerce-pagination ul.page-numbers .prev
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 13 5.9296875 L 6.9296875 12 L 13 18.070312 L 14.5 16.570312 L 9.9296875 12 L 14.5 7.4296875 L 13 5.9296875 z'></path></svg>");
	}

	body.archive:not(.woocommerce) .posts-navigation .nav-links .next:hover:after,
	body.blog:not(.woocommerce) .posts-navigation .nav-links .next:hover:after,
	.woocommerce .woocommerce-pagination ul.page-numbers .next:hover
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 10 5.9296875 L 8.5 7.4296875 L 13.070312 12 L 8.5 16.570312 L 10 18.070312 L 16.070312 12 L 10 5.9296875 z'></path></svg>");
	}

	body.archive:not(.woocommerce) .posts-navigation .nav-links .prev:hover:after,
	body.blog:not(.woocommerce) .posts-navigation .nav-links .prev:hover:after,
	.woocommerce .woocommerce-pagination ul.page-numbers .prev:hover
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='rgb(255,255,255)'><path d='M 13 5.9296875 L 6.9296875 12 L 13 18.070312 L 14.5 16.570312 L 9.9296875 12 L 14.5 7.4296875 L 13 5.9296875 z'></path></svg>");
	}

	.widget-area .widget.woocommerce.widget_product_categories ul li > a:before,
	.widget-area .widget.woocommerce.widget_layered_nav ul li > a:before,
	.widget-area .widget.woocommerce.widget_layered_nav_filters ul li > a:before,
	.widget-area .widget.widget_categories ul li > a:before,
	.widget-area .widget.widget_archive ul li > a:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 2 C 6.4889971 2 2 6.4889971 2 12 C 2 17.511003 6.4889971 22 12 22 C 17.511003 22 22 17.511003 22 12 C 22 6.4889971 17.511003 2 12 2 z M 12 4 C 16.430123 4 20 7.5698774 20 12 C 20 16.430123 16.430123 20 12 20 C 7.5698774 20 4 16.430123 4 12 C 4 7.5698774 7.5698774 4 12 4 z'></path></svg>");
	}

	.widget-area .widget.woocommerce.widget_product_categories ul li > a:hover:before,
	.widget-area .widget.woocommerce.widget_layered_nav ul li > a:hover:before,
	.widget-area .widget.woocommerce.widget_layered_nav_filters ul li > a:hover:before,
	.widget-area .widget.widget_categories ul li > a:hover:before,
	.widget-area .widget.widget_archive ul li > a:hover:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 2 A 10 10 0 0 0 2 12 A 10 10 0 0 0 12 22 A 10 10 0 0 0 22 12 A 10 10 0 0 0 12 2 z'></path></svg>");
	}

	.widget-area .widget.woocommerce.widget_product_categories ul li.current-cat > a:before,
	.widget-area .widget.woocommerce.widget_product_categories ul li.current-cat > a:hover:before,
	.widget-area .widget.woocommerce.widget_layered_nav ul li.chosen > a:before,
	.widget-area .widget.woocommerce.widget_layered_nav_filters ul li.chosen > a:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 2 C 6.4889971 2 2 6.4889971 2 12 C 2 17.511003 6.4889971 22 12 22 C 17.511003 22 22 17.511003 22 12 C 22 6.4889971 17.511003 2 12 2 z M 12 4 C 16.430123 4 20 7.5698774 20 12 C 20 16.430123 16.430123 20 12 20 C 7.5698774 20 4 16.430123 4 12 C 4 7.5698774 7.5698774 4 12 4 z M 16.292969 8.2929688 L 10 14.585938 L 7.7070312 12.292969 L 6.2929688 13.707031 L 10 17.414062 L 17.707031 9.7070312 L 16.292969 8.2929688 z'></path></svg>");
	}

	.widget-area .widget.woocommerce.widget_layered_nav ul li.chosen > a:hover:before,
	.widget-area .widget.woocommerce.widget_layered_nav_filters ul li.chosen > a:hover:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 2 C 6.4889971 2 2 6.4889971 2 12 C 2 17.511003 6.4889971 22 12 22 C 17.511003 22 22 17.511003 22 12 C 22 6.4889971 17.511003 2 12 2 z M 12 4 C 16.430123 4 20 7.5698774 20 12 C 20 16.430123 16.430123 20 12 20 C 7.5698774 20 4 16.430123 4 12 C 4 7.5698774 7.5698774 4 12 4 z M 8.7070312 7.2929688 L 7.2929688 8.7070312 L 10.585938 12 L 7.2929688 15.292969 L 8.7070312 16.707031 L 12 13.414062 L 15.292969 16.707031 L 16.707031 15.292969 L 13.414062 12 L 16.707031 8.7070312 L 15.292969 7.2929688 L 12 10.585938 L 8.7070312 7.2929688 z'></path></svg>");
	}

	.widget-area .widget.widget_recent_entries ul li:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 6 2 C 4.9057453 2 4 2.9057453 4 4 L 4 20 C 4 21.094255 4.9057453 22 6 22 L 18 22 C 19.094255 22 20 21.094255 20 20 L 20 8 L 14 2 L 6 2 z M 6 4 L 13 4 L 13 9 L 18 9 L 18 20 L 6 20 L 6 4 z M 8 12 L 8 14 L 16 14 L 16 12 L 8 12 z M 8 16 L 8 18 L 16 18 L 16 16 L 8 16 z'></path></svg>");
	}

	.widget-area .widget.widget_recent_comments ul li:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 2 C 6.5486138 2 2 5.9740326 2 11 C 2 16.025967 6.5486138 20 12 20 C 12.346168 20 12.665158 19.93053 13 19.898438 L 13 23.09375 L 14.541016 22.105469 C 16.703198 20.717704 21.385038 17.115414 21.943359 11.945312 C 21.978757 11.637749 22 11.322745 22 11 C 22 5.9740326 17.451386 2 12 2 z M 12 4 C 16.490614 4 20 7.1899674 20 11 C 20 11.240597 19.985091 11.480626 19.957031 11.722656 L 19.957031 11.726562 L 19.955078 11.730469 C 19.609498 14.93103 17.047504 17.44485 15 19.083984 L 15 17.572266 L 13.802734 17.814453 C 13.217083 17.932675 12.615326 18 12 18 C 7.5093862 18 4 14.810033 4 11 C 4 7.1899674 7.5093862 4 12 4 z M 7 10 L 7 12 L 9 12 L 9 10 L 7 10 z M 11 10 L 11 12 L 13 12 L 13 10 L 11 10 z M 15 10 L 15 12 L 17 12 L 17 10 L 15 10 z'></path></svg>");
	}

	.widget-area .widget.widget_rss ul li:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 5 3 C 3.9069372 3 3 3.9069372 3 5 L 3 19 C 3 20.093063 3.9069372 21 5 21 L 19 21 C 20.093063 21 21 20.093063 21 19 L 21 5 C 21 3.9069372 20.093063 3 19 3 L 5 3 z M 5 5 L 19 5 L 19 19 L 5 19 L 5 5 z M 7 7 L 7 9 L 8 9 C 11.877484 9 15 12.122516 15 16 L 15 17 L 17 17 L 17 16 C 17 11.041484 12.958516 7 8 7 L 7 7 z M 7 11 L 7 13 L 8 13 C 9.6684839 13 11 14.331516 11 16 L 11 17 L 13 17 L 13 16 C 13 13.250484 10.749516 11 8 11 L 7 11 z M 8 15 A 1 1 0 0 0 7 16 A 1 1 0 0 0 8 17 A 1 1 0 0 0 9 16 A 1 1 0 0 0 8 15 z'></path></svg>");
	}

	.logout-icon
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 11 2 L 11 12 L 13 12 L 13 2 L 11 2 z M 9 2.4589844 C 4.943 3.7339844 2 7.523 2 12 C 2 17.523 6.477 22 12 22 C 17.523 22 22 17.523 22 12 C 22 7.523 19.057 3.7339844 15 2.4589844 L 15 4.5878906 C 17.931 5.7748906 20 8.644 20 12 C 20 16.418 16.418 20 12 20 C 7.582 20 4 16.418 4 12 C 4 8.643 6.069 5.7748906 9 4.5878906 L 9 2.4589844 z'></path></svg>");
	}

	.single-comments .single-comments-icon
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 12 2 C 6.5486138 2 2 5.9740326 2 11 C 2 16.025967 6.5486138 20 12 20 C 12.346168 20 12.665158 19.93053 13 19.898438 L 13 23.09375 L 14.541016 22.105469 C 16.703198 20.717704 21.385038 17.115414 21.943359 11.945312 C 21.978757 11.637749 22 11.322745 22 11 C 22 5.9740326 17.451386 2 12 2 z M 12 4 C 16.490614 4 20 7.1899674 20 11 C 20 11.240597 19.985091 11.480626 19.957031 11.722656 L 19.957031 11.726562 L 19.955078 11.730469 C 19.609498 14.93103 17.047504 17.44485 15 19.083984 L 15 17.572266 L 13.802734 17.814453 C 13.217083 17.932675 12.615326 18 12 18 C 7.5093862 18 4 14.810033 4 11 C 4 7.1899674 7.5093862 4 12 4 z M 7 10 L 7 12 L 9 12 L 9 10 L 7 10 z M 11 10 L 11 12 L 13 12 L 13 10 L 11 10 z M 15 10 L 15 12 L 17 12 L 17 10 L 15 10 z'></path></svg>");
	}

	.single-date .single-date-icon
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 6 1 L 6 3 L 5 3 C 3.9 3 3 3.9 3 5 L 3 19 C 3 20.1 3.9 21 5 21 L 19 21 C 20.1 21 21 20.1 21 19 L 21 5 C 21 3.9 20.1 3 19 3 L 18 3 L 18 1 L 16 1 L 16 3 L 8 3 L 8 1 L 6 1 z M 5 5 L 6 5 L 8 5 L 16 5 L 18 5 L 19 5 L 19 7 L 5 7 L 5 5 z M 5 9 L 19 9 L 19 19 L 5 19 L 5 9 z'></path></svg>");
	}

	.comments_section ul li article .comment-text .comment-reply:before
	{
		content: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='rgb(0,0,0)'><path d='M 7.2929688 2.2929688 L 2.5859375 7 L 7.2929688 11.707031 L 8.7070312 10.292969 L 6.4140625 8 L 15 8 C 17.220375 8 19 9.7796254 19 12 L 19 21 L 21 21 L 21 12 C 21 8.6983746 18.301625 6 15 6 L 6.4140625 6 L 8.7070312 3.7070312 L 7.2929688 2.2929688 z'></path></svg>");
	}


	body header h1.page-title,
	h1.shop-page-title.entry-title.page-title,
	h1.blog-header,
	.woocommerce ul.products li.product .shop_archive_wishlist .yith-wcwl-add-to-wishlist a,
	body.blog:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post article.sticky .bg-image-wrapper::before,
	body.blog:not(.woocommerce) .blog_layout_2 .blog_posts .blog_post article.sticky .bg-image-wrapper::before,
	body.archive:not(.woocommerce) .blog_layout_1 .blog_posts .blog_post article.sticky .bg-image-wrapper::before,
	body.archive:not(.woocommerce) .blog_layout_2 .blog_posts .blog_post article.sticky .bg-image-wrapper::before
	{
		background-color: #ffc741;
	}

	.woocommerce-account .woocommerce .myaccount_user strong, 
	.woocommerce-account .woocommerce .myaccount_user a,
	.woocommerce-account .woocommerce .shop_table td.order-number a,
	.woocommerce-account .woocommerce .shop_table td.order-actions a,
	.woocommerce-account .woocommerce .addresses header.title a.edit,
	a.shipping-calculator-button,
	.woocommerce-info a,
	.wc_payment_method a,
	.shipping-calculator-button,
	.woocommerce-account .woocommerce .woocommerce-MyAccount-content > p:last-child a,
	.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-add-button:before,
	.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistaddedbrowse:before,
	.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistexistsbrowse:before
	{
		color: #ffc741;
	}

	.about_paypal,
	.payment_box a
	{
		color: #000!important;
	}

	.woocommerce-account .woocommerce .myaccount_user,
	.woocommerce-account .woocommerce .order-info,
	.wc_payment_method a,
	.shipping-calculator-button,
	.woocommerce-account .woocommerce .woocommerce-MyAccount-content > p:first-child
	{
		border-bottom: 2px solid #ffc741;
	}

	.woocommerce-terms-and-conditions-link,
	.woocommerce-privacy-policy-link,
	.about_paypal,
	.payment_box a
	{
		border-bottom: 2px solid #000!important;
	}

		@media only screen and (min-width: 64em) and (max-width: 1024px) {

			.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-add-button:before,
			.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistaddedbrowse:before,
			.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistexistsbrowse:before
			{
				background-color: #ffc741!important;
			}

			.site-header-mobiles
			{
				display: block !important;
			}

			.site-header .header-wrapper
			{
				display: none !important;
			}

			.site-content
			{
				padding-top: 55px !important;
			}

			body.offcanvas_left .site-header-mobiles {
			    -webkit-transform: translate3d(400px, 0, 0);
			    transform: translate3d(400px, 0, 0);
			}

			body.offcanvas_right .site-header-mobiles {
			    -webkit-transform: translate3d(-400px, 0, 0);
			    transform: translate3d(-400px, 0, 0);
			}

			.site-header-mobiles
			{
				background-color: #23282d!important;
			}

			.site-header-mobiles .tools_button_icon,
			.site-header-mobiles .tools_button_text,
			.site-header-mobiles .tools_button
			{
				color: #fff!important;
			}

			.tools_button_icon.uploaded_icon svg
			{
				fill: #fff!important;
			}
		}
	

	@media screen and (min-width: 64em) {

		.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-add-button:before,
		.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistaddedbrowse:before,
		.woocommerce .product_infos .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistexistsbrowse:before
		{
			background-color: #ffc741!important;
			color: #fff;
		}
	}

		.woocommerce ul.products li.product
		{
			padding: 0px;
		}
	

	.wp-block-pullquote
	{
		border-color: #000;
	}

	.wp-block-latest-posts__post-date,
	.wp-block-audio figcaption,
	.wp-block-video figcaption,
	.wp-block-image figcaption
	{
		color: rgba(0,0,0, 0.6);
	}

	p.has-drop-cap:not(:focus)::first-letter
	{
		font-size: 64.00008px;
	}

	.wp-block-cover .wp-block-cover-text
	{
		font-size: 36px;
	}

	.wp-block-latest-posts li a
	{
		font-size: 21.99996px;
	}

	.wp-block-quote p,
	.wp-block-pullquote p,
	.wp-block-quote cite,
	.wp-block-pullquote cite,
	.wc-block-grid__product-title
	{
		color: #000;
	}

	.wp-block-archives .count
	{
		color: rgba(0,0,0, 0.6);
	}

</style>
<!--[if lt IE 9]>
<link rel='stylesheet' id='vc_lte_ie9-group-css' href='https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/plugins/bwp-minify/cache/minify-b1-vc_lte_ie9-66081069cd27d89b53cb47522402c4f5.css?ver=1568217794' type='text/css' media='screen' />
<![endif]-->
<script type="text/template" id="tmpl-variation-template">
	<div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
	<div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
	<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
</script>
<script type="text/template" id="tmpl-unavailable-variation-template">
	<p>Sorry, this product is unavailable. Please choose a different combination.</p>
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/merchandiser.wp-theme.design\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"https:\/\/merchandiser.wp-theme.design\/wp-includes\/js\/zxcvbn.min.js"};
/* ]]> */
</script>
<script type='text/javascript' src='https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/plugins/bwp-minify/cache/minify-b1-jquery-core-b7f0583af2b164d7940cc5567f7bf22c.js?ver=1568217794'></script>
<script type='text/javascript' src='//platform-api.sharethis.com/js/sharethis.js#product=ga'></script>
<link rel='https://api.w.org/' href='https://merchandiser.wp-theme.design/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://merchandiser.wp-theme.design/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.2.3" />
<meta name="generator" content="WooCommerce 3.7.0" />
 
          <script type="text/javascript">
            var ajaxurl = "https://merchandiser.wp-theme.design/wp-admin/admin-ajax.php"; 
          </script>
                  <style type="text/css">
                  
              .fb_dialog, .fb-customerchat:not(.fb_iframe_widget_fluid) iframe{
                margin-bottom: 0px !important;
              }
          </style>
          <script>      
                          window.fbMessengerPlugins = window.fbMessengerPlugins || { 
                init: function () { 
                  FB.init({ 
                      appId:'983715691729450',
                      autoLogAppEvents : true,
                      xfbml : true,
                      version: 'v2.11'});
                  }, 
                  callable: []      
              };
              window.fbAsyncInit = window.fbAsyncInit || function () { 
                  window.fbMessengerPlugins.callable.forEach(function (item) { item(); });        window.fbMessengerPlugins.init(); 
              };
                            setTimeout(function () {  
                (function (d, s, id) {  
                    var js, fjs = d.getElementsByTagName(s)[0]; 
                    if (d.getElementById(id)) { return; } 
                    js = d.createElement(s);
                    js.id = id;
                    js.src = "//connect.facebook.net/en_US/sdk/xfbml.customerchat.js"; 
                    fjs.parentNode.insertBefore(js, fjs);        
                }(document, 'script', 'facebook-jssdk')); }, 0);  
                  
          </script> 
          <div class="fb-customerchat" page_id="182105075255571" ref="" theme_color=""
                                  ></div>
              	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<link rel="icon" href="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2018/07/favicon.png" sizes="32x32" />
<link rel="icon" href="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2018/07/favicon.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2018/07/favicon.png" />
<meta name="msapplication-TileImage" content="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2018/07/favicon.png" />
		<style type="text/css" id="wp-custom-css">
			 .main-navigation-flyout.left .menu-main-navigation
{
	padding-left: 2em;
}

.fb_dialog, .fb-customerchat:not(.fb_iframe_widget_fluid) iframe {
    margin-bottom: 15px !important;
}

.fb_dialog {
    box-shadow: -6.772px 8.668px 16px 0px rgba(28, 30, 35, 0.15);
    -webkit-box-shadow: -6.772px 8.668px 16px 0px rgba(28, 30, 35, 0.15);
    -moz-box-shadow: -6.772px 8.668px 16px 0px rgba(28, 30, 35, 0.15);
}

.getbowtied_get_this_theme {
    bottom: 30px;
    right: 75px;
}

.site-header .header-wrapper .tools ul li a.tools_button .tools_button_icon {
 padding: 10px !important;

}		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

<body class="error404 wp-embed-responsive theme-merchandiser woocommerce-no-js wpb-js-composer js-comp-ver-6.0.5 vc_responsive header-sticky header-layout-1   no-offcanvas-animation ">

    

<header class="site-header"> 
        
    <div class="header-wrapper">

        
        
		
        <div class="site-branding">

            
                <div class="site-logo">
                    <a href="https://merchandiser.wp-theme.design/" rel="home">
                        <img src="//merchandiser.wp-theme.design/wp-content/uploads/2017/06/merchandiser-thumb.png" alt="Merchandiser">
                    </a>

                                            <a href="https://merchandiser.wp-theme.design/" rel="home" class="sticky-header-logo">
                            <img src="//merchandiser.wp-theme.design/wp-content/uploads/2017/06/merchandiser-thumb.png" alt="Merchandiser">
                        </a>
                                    </div>

            
        </div>

        
        <div class="nav">

            
                <nav class="main-navigation-slices" >                    
                    <ul class="menu-main-navigation"><li id="menu-item-3566" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-3566"><a href="http://merchandiser.wp-theme.design/">Home</a>
<ul class="sub-menu">
	<li id="menu-item-4623" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-4623"><a href="http://merchandiser.wp-theme.design/">Home</a>
	<ul class="sub-menu">
		<li id="menu-item-277" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-277"><a href="https://merchandiser.wp-theme.design/">Home V1 — Slider / eCommerce</a></li>
		<li id="menu-item-3851" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3851"><a href="https://merchandiser.wp-theme.design/home/home-v2-ecommerce-products/">Home V2 — eCommerce Products</a></li>
		<li id="menu-item-3964" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3964"><a href="https://merchandiser.wp-theme.design/home/home-v3-ecommerce-categories/">Home V3 — eCommerce Categories</a></li>
		<li id="menu-item-4383" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4383"><a href="https://merchandiser.wp-theme.design/home/home-v4-product-landing-page/">Home V4 — Product Landing Page</a></li>
		<li id="menu-item-3933" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3933"><a href="https://merchandiser.wp-theme.design/home/home-v5-full-width-categories/">Home V5 — Full-width Categories</a></li>
		<li id="menu-item-4011" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4011"><a href="https://merchandiser.wp-theme.design/home/home-v6-parallax-sections/">Home V6 — Parallax Sections</a></li>
		<li id="menu-item-3967" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3967"><a href="https://merchandiser.wp-theme.design/home/home-v7-categories-video/">Home V7 — Categories / Video</a></li>
		<li id="menu-item-3935" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3935"><a href="https://merchandiser.wp-theme.design/home/home-v8-full-width-categories-b/">Home V8 — Full-width Categories B</a></li>
		<li id="menu-item-4014" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4014"><a href="https://merchandiser.wp-theme.design/home/home-v9-product-collections/">Home V9 — Product Collections</a></li>
		<li id="menu-item-2801" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2801"><a href="https://merchandiser.wp-theme.design/home/splash-v1-coming-soon/">Splash V1 — Coming Soon</a></li>
		<li id="menu-item-4331" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4331"><a href="https://merchandiser.wp-theme.design/home/splash-v2-coming-soon/">Splash V2 — Coming Soon</a></li>
		<li id="menu-item-4338" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4338"><a href="https://merchandiser.wp-theme.design/home/splash-v3-coming-soon/">Splash V3 — Coming Soon</a></li>
	</ul>
</li>
	<li id="menu-item-35" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-35"><a href="#">Secondary Pages</a>
	<ul class="sub-menu">
		<li id="menu-item-4444" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4444"><a href="https://merchandiser.wp-theme.design/about-v1/">About V1</a></li>
		<li id="menu-item-4443" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4443"><a href="https://merchandiser.wp-theme.design/about-v2/">About V2</a></li>
		<li id="menu-item-1574" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1574"><a href="https://merchandiser.wp-theme.design/about-v3/">About V3</a></li>
		<li id="menu-item-1581" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1581"><a href="https://merchandiser.wp-theme.design/faqs/">FAQs</a></li>
		<li id="menu-item-1580" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1580"><a href="https://merchandiser.wp-theme.design/contact/">Contact V1</a></li>
		<li id="menu-item-4551" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4551"><a href="https://merchandiser.wp-theme.design/contact-v2/">Contact V2</a></li>
	</ul>
</li>
	<li id="menu-item-31" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-31"><a href="#">Blog</a>
	<ul class="sub-menu">
		<li id="menu-item-4562" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4562"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=c830085a-aa15-4d23-913a-085d39737d74">Blog Layout V1</a></li>
		<li id="menu-item-4563" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4563"><a href="http://merchandiser.wp-theme.design/blog/?no-preset">Blog Layout V2</a></li>
		<li id="menu-item-4564" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4564"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=5daf0f96-196c-4dcd-a128-cf86243f8313">Blog Layout V3</a></li>
		<li id="menu-item-4565" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4565"><a href="http://merchandiser.wp-theme.design/100-scandinavian-with-twee-wayfarers/?customize_changeset_uuid_gbt=41798d90-a6a5-4eeb-83e7-352f0e705bf7">Single Post V1</a></li>
		<li id="menu-item-4566" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4566"><a href="http://merchandiser.wp-theme.design/100-scandinavian-with-twee-wayfarers/?no-preset">Single Post V2</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-22"><a href="https://merchandiser.wp-theme.design/shop/">Shop</a>
<ul class="sub-menu">
	<li id="menu-item-43" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-43"><a href="https://merchandiser.wp-theme.design/shop/">Shop</a>
	<ul class="sub-menu">
		<li id="menu-item-5140" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5140"><a href="https://merchandiser.wp-theme.design/shop/?no-preset">Shop — with Sidebar</a></li>
		<li id="menu-item-3567" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3567"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=efa1526c-e903-4001-a749-5b2ef44f4b9c">Shop — No Sidebar</a></li>
		<li id="menu-item-2803" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2803"><a href="https://merchandiser.wp-theme.design/product-category/kitchen-dining/">Shop — A Product Category</a></li>
		<li id="menu-item-4567" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4567"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=47fba0d9-8937-4558-9fce-9c7674ceeafe">Shop — 1 Products</a></li>
		<li id="menu-item-3368" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3368"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=ca6421d5-d034-49c2-86fc-aa12d4acc299">Shop — 2 Products</a></li>
		<li id="menu-item-3369" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3369"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=a8d7e476-3bd4-4744-b6a3-510f2c693d5a">Shop — 3 Products</a></li>
		<li id="menu-item-3370" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3370"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=563b31d7-045e-468a-97ec-3fc62d2f0972">Shop — 4 Products</a></li>
		<li id="menu-item-3371" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3371"><a href="http://merchandiser.wp-theme.design/shop/?no-preset">Shop — 5 Products</a></li>
		<li id="menu-item-3372" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3372"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=9332327f-24ed-42d8-a919-c6f39bd8abdd">Shop — 6 Products</a></li>
	</ul>
</li>
	<li id="menu-item-40" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-40"><a href="#">Products</a>
	<ul class="sub-menu">
		<li id="menu-item-53" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-53"><a href="https://merchandiser.wp-theme.design/shop/seating/simple-product/">Simple Product</a></li>
		<li id="menu-item-2628" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-2628"><a href="https://merchandiser.wp-theme.design/shop/seating/purple-dining-chair/">Variable Product <sup>Color / Size / Custom</sup></a></li>
		<li id="menu-item-59" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-59"><a href="https://merchandiser.wp-theme.design/shop/seating/external-affiliate-product/">External / Affiliate Product</a></li>
		<li id="menu-item-2581" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-2581"><a href="https://merchandiser.wp-theme.design/shop/kitchen-dining/hi-cut-transparent-chair/">Grouped Product</a></li>
		<li id="menu-item-1399" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1399"><a href="https://merchandiser.wp-theme.design/shop/kitchen-dining/clear-swingtop-bottles/">Out of Stock</a></li>
		<li id="menu-item-2804" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-2804"><a href="https://merchandiser.wp-theme.design/shop/seating/fivee-houseplant-pot/">Product on Sale</a></li>
	</ul>
</li>
	<li id="menu-item-41" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-41"><a href="#">Orders</a>
	<ul class="sub-menu">
		<li id="menu-item-18" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18"><a href="https://merchandiser.wp-theme.design/cart/">Shopping Cart</a></li>
		<li id="menu-item-19" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19"><a href="https://merchandiser.wp-theme.design/checkout/">Checkout</a></li>
		<li id="menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-42"><a href="https://merchandiser.wp-theme.design/my-account/">Login / Register</a></li>
		<li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="https://merchandiser.wp-theme.design/my-account/">My Account</a></li>
		<li id="menu-item-68" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-68"><a href="https://merchandiser.wp-theme.design/order-tracking/">Order Tracking</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-26" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-has-children menu-item-26"><a href="https://merchandiser.wp-theme.design/blog/">Blog</a>
<ul class="sub-menu">
	<li id="menu-item-4568" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-has-children menu-item-4568"><a href="https://merchandiser.wp-theme.design/blog/">Blog Layouts</a>
	<ul class="sub-menu">
		<li id="menu-item-4577" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4577"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=c830085a-aa15-4d23-913a-085d39737d74">Blog — Layout V1</a></li>
		<li id="menu-item-4578" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4578"><a href="http://merchandiser.wp-theme.design/blog/?no-preset">Blog — Layout V2</a></li>
		<li id="menu-item-4579" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4579"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=5daf0f96-196c-4dcd-a128-cf86243f8313">Blog — Layout V3</a></li>
	</ul>
</li>
	<li id="menu-item-4569" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-has-children menu-item-4569"><a href="https://merchandiser.wp-theme.design/100-scandinavian-with-twee-wayfarers/">Single Posts</a>
	<ul class="sub-menu">
		<li id="menu-item-4575" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4575"><a href="http://merchandiser.wp-theme.design/100-scandinavian-with-twee-wayfarers/?customize_changeset_uuid_gbt=41798d90-a6a5-4eeb-83e7-352f0e705bf7">Blog — Single Post V1</a></li>
		<li id="menu-item-4576" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4576"><a href="http://merchandiser.wp-theme.design/100-scandinavian-with-twee-wayfarers/?no-preset">Blog — Single Post V2</a></li>
	</ul>
</li>
	<li id="menu-item-4571" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-has-children menu-item-4571"><a href="https://merchandiser.wp-theme.design/blog/">Pagination</a>
	<ul class="sub-menu">
		<li id="menu-item-4572" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4572"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=c361be75-5448-4e69-b05f-2e7fd0f9fe8f">Pagination — Classic</a></li>
		<li id="menu-item-4573" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4573"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=9615284b-5fc7-454b-9f73-bf05ec275056">Pagination — Load More</a></li>
		<li id="menu-item-4574" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4574"><a href="http://merchandiser.wp-theme.design/blog/?no-preset">Pagination — Infinite</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-3624" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-3624"><a href="#">Elements</a>
<ul class="sub-menu">
	<li id="menu-item-4384" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4384"><a href="#">Page Builder Products</a>
	<ul class="sub-menu">
		<li id="menu-item-147" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-147"><a href="https://merchandiser.wp-theme.design/elements/product-categories-grid/">Product Categories Grid</a></li>
		<li id="menu-item-146" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-146"><a href="https://merchandiser.wp-theme.design/elements/recent-products/">Recent Products</a></li>
		<li id="menu-item-145" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-145"><a href="https://merchandiser.wp-theme.design/elements/products-by-category/">Products by Category</a></li>
		<li id="menu-item-144" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-144"><a href="https://merchandiser.wp-theme.design/elements/products-by-attribute/">Products by Attribute</a></li>
		<li id="menu-item-143" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-143"><a href="https://merchandiser.wp-theme.design/elements/top-rated-products/">Top Rated Products</a></li>
		<li id="menu-item-142" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-142"><a href="https://merchandiser.wp-theme.design/elements/best-selling-products/">Best Selling Products</a></li>
		<li id="menu-item-141" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-141"><a href="https://merchandiser.wp-theme.design/elements/featured-products/">Featured Products</a></li>
		<li id="menu-item-140" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-140"><a href="https://merchandiser.wp-theme.design/elements/products-on-sale/">Products on Sale</a></li>
		<li id="menu-item-139" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-139"><a href="https://merchandiser.wp-theme.design/elements/products-custom-list/">Products – Custom List</a></li>
		<li id="menu-item-138" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-138"><a href="https://merchandiser.wp-theme.design/elements/add-to-cart-button/">Add to Cart Button</a></li>
		<li id="menu-item-137" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-137"><a href="https://merchandiser.wp-theme.design/elements/single-product/">Single Product</a></li>
	</ul>
</li>
	<li id="menu-item-4447" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4447"><a href="#">Page Builder Content</a>
	<ul class="sub-menu">
		<li id="menu-item-163" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-163"><a href="https://merchandiser.wp-theme.design/elements/banners/">Banners</a></li>
		<li id="menu-item-1466" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1466"><a href="https://merchandiser.wp-theme.design/elements/tabs/">Tabs</a></li>
		<li id="menu-item-1778" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1778"><a href="https://merchandiser.wp-theme.design/elements/toggles-faqs/">Toggles / FAQs</a></li>
		<li id="menu-item-1464" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1464"><a href="https://merchandiser.wp-theme.design/elements/accordions/">Accordions</a></li>
		<li id="menu-item-161" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-161"><a href="https://merchandiser.wp-theme.design/elements/social-media/">Social Media</a></li>
		<li id="menu-item-1884" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1884"><a href="https://merchandiser.wp-theme.design/elements/images-image-galleries/">Image Galleries</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-4479" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4479"><a href="https://merchandiser.wp-theme.design/merchandiser-ecommerce-wordpress-theme/">Features</a></li>
</ul>                </nav>

            
        </div>

        
        <div class="tools">
            
            <ul>

            	<!-- Wishlist Button -->
                                                                
                <li class="wishlist-button">
                    <a class="tools_button" href="https://merchandiser.wp-theme.design/wishlist/">
                        
                                                    
                            <span class="tools_button_icon wishlist-icon"></span>

                                                
                        <span class="wishlist_items_number">1</span>

                    </a>
                </li>

                                                                
                <!-- Search Button -->
                                
                <li class="search-button">
                    <a class="tools_button">
                        
                            
                                                            
                                <span class="tools_button_icon search-icon"></span>

                            
                        
                    </a>
                </li>

                
                <!-- Shopping Bag Button -->
                                                
                <li class="shopping-bag-button">
                    <a class="tools_button" href="https://merchandiser.wp-theme.design/cart/">
                        
                                                    
                            <span class="tools_button_icon shopping-cart-icon"></span>

                                                
                        <span class="shopping_bag_items_number">8</span>

                    </a>
                </li>

                                
                <!-- My Account -->
                                                
                <li class="my-account-button">
                    
                                            <a class="tools_button my-account-login-button" href="https://merchandiser.wp-theme.design/my-account/">
                            
                                                            
                                <span class="tools_button_icon account-icon"></span>

                                                        
                        </a>
                    
                </li>
                
                                
            </ul>

        </div>

    </div>

    <div class="search_wrapper">

	    <div class="getbowtied_search_bar">
	        
<div class="getbowtied-ajaxsearchform-container">
    <form class="woocommerce-product-search getbowtied-ajaxsearchform" role="search" method="get" action="https://merchandiser.wp-theme.design/">
        <div>
            <label class="screen-reader-text" for="getbowtied-s">Search for:</label>

            <input type="search"
                   value=""
                   name="s"
                   class="search-field getbowtied-s"
                   placeholder="Search products&hellip;"
                   data-loader-icon=""
                   data-min-chars="3"
                   title="Search for:" />

            <input type="submit" class="getbowtied-searchsubmit" value="Search" />
            <input type="hidden" name="post_type" value="product" />
        </div>
    </form>
</div>

	    </div>

	    <ul class="search-widget-area widget-area adjust_cols_height">
	        <li class="widget woocommerce widget_product_categories"><h4 class="widget-title">Browse Categories</h4><ul class="product-categories"><li class="cat-item cat-item-129"><a href="https://merchandiser.wp-theme.design/product-category/accessories/">Accessories</a> <span class="count">4</span></li>
<li class="cat-item cat-item-137 cat-parent"><a href="https://merchandiser.wp-theme.design/product-category/categories-grid/">Categories Grid</a> <span class="count">0</span></li>
<li class="cat-item cat-item-30"><a href="https://merchandiser.wp-theme.design/product-category/seating/">Furniture</a> <span class="count">42</span></li>
<li class="cat-item cat-item-133"><a href="https://merchandiser.wp-theme.design/product-category/kitchen/">Kitchen</a> <span class="count">2</span></li>
<li class="cat-item cat-item-9"><a href="https://merchandiser.wp-theme.design/product-category/kitchen-dining/">Kitchen &amp; Dining</a> <span class="count">12</span></li>
<li class="cat-item cat-item-116"><a href="https://merchandiser.wp-theme.design/product-category/lighting/">Lighting</a> <span class="count">9</span></li>
<li class="cat-item cat-item-179"><a href="https://merchandiser.wp-theme.design/product-category/uncategorized/">Uncategorized</a> <span class="count">0</span></li>
<li class="cat-item cat-item-130"><a href="https://merchandiser.wp-theme.design/product-category/vintage/">Vintage</a> <span class="count">2</span></li>
</ul></li><li class="widget woocommerce widget_products"><h4 class="widget-title">Featured Products</h4><ul class="product_list_widget"><li>
	
	<a href="https://merchandiser.wp-theme.design/shop/kitchen-dining/bold-cubism-tray-french-blue/">
		<img width="500" height="500" src="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/08/mariska-meijers-bold-cubism-tray-fre-500x500.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/08/mariska-meijers-bold-cubism-tray-fre-500x500.jpg 500w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/08/mariska-meijers-bold-cubism-tray-fre-100x100.jpg 100w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/08/mariska-meijers-bold-cubism-tray-fre-960x960.jpg 960w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/08/mariska-meijers-bold-cubism-tray-fre-150x150.jpg 150w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/08/mariska-meijers-bold-cubism-tray-fre-300x300.jpg 300w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/08/mariska-meijers-bold-cubism-tray-fre-768x768.jpg 768w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/08/mariska-meijers-bold-cubism-tray-fre-1024x1024.jpg 1024w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/08/mariska-meijers-bold-cubism-tray-fre.jpg 1600w" sizes="(max-width: 500px) 100vw, 500px" />		<span class="product-title">Bold Cubism Tray - French Blue</span>
	</a>

			<div class="star-rating" role="img" aria-label="Rated 4.00 out of 5"><span style="width:80%">Rated <strong class="rating">4.00</strong> out of 5</span></div>	
	<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>151</span>
	</li>
<li>
	
	<a href="https://merchandiser.wp-theme.design/shop/seating/mid-century-modern-eames-style-patchwork-fabric/">
		<img width="500" height="500" src="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/034-Patchwork-Fabric-Chair-with-Metal-Legs-500x500.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/034-Patchwork-Fabric-Chair-with-Metal-Legs-500x500.jpg 500w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/034-Patchwork-Fabric-Chair-with-Metal-Legs-100x100.jpg 100w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/034-Patchwork-Fabric-Chair-with-Metal-Legs-960x960.jpg 960w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/034-Patchwork-Fabric-Chair-with-Metal-Legs-150x150.jpg 150w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/034-Patchwork-Fabric-Chair-with-Metal-Legs-300x300.jpg 300w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/034-Patchwork-Fabric-Chair-with-Metal-Legs-768x768.jpg 768w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/034-Patchwork-Fabric-Chair-with-Metal-Legs-1024x1024.jpg 1024w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/034-Patchwork-Fabric-Chair-with-Metal-Legs.jpg 1600w" sizes="(max-width: 500px) 100vw, 500px" />		<span class="product-title">Mid Century Modern Eames Style Patchwork Fabric</span>
	</a>

				
	<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>142</span>
	</li>
<li>
	
	<a href="https://merchandiser.wp-theme.design/shop/seating/sail-metal-dining-chair/">
		<img width="500" height="500" src="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/sail-001-500x500.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/sail-001-500x500.jpg 500w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/sail-001-100x100.jpg 100w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/sail-001-960x960.jpg 960w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/sail-001-150x150.jpg 150w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/sail-001-300x300.jpg 300w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/sail-001-768x768.jpg 768w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/sail-001-1024x1024.jpg 1024w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/sail-001.jpg 1600w" sizes="(max-width: 500px) 100vw, 500px" />		<span class="product-title">Sail Metal Dining Chair</span>
	</a>

				
	<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>211</span>
	</li>
</ul></li><li class="widget woocommerce widget_products"><h4 class="widget-title">Sales</h4><ul class="product_list_widget"><li>
	
	<a href="https://merchandiser.wp-theme.design/shop/seating/emfa-white-chair/">
		<img width="500" height="500" src="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/emfa-001-500x500.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/emfa-001-500x500.jpg 500w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/emfa-001-100x100.jpg 100w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/emfa-001-960x960.jpg 960w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/emfa-001-150x150.jpg 150w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/emfa-001-300x300.jpg 300w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/emfa-001-768x768.jpg 768w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/emfa-001-1024x1024.jpg 1024w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/emfa-001.jpg 1600w" sizes="(max-width: 500px) 100vw, 500px" />		<span class="product-title">Emfa White Chair</span>
	</a>

				
	<del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>110</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>100</span></ins>
	</li>
<li>
	
	<a href="https://merchandiser.wp-theme.design/shop/lighting/dante-studio-lightling/">
		<img width="500" height="500" src="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/dante-001-500x500.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/dante-001-500x500.jpg 500w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/dante-001-100x100.jpg 100w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/dante-001-960x960.jpg 960w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/dante-001-150x150.jpg 150w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/dante-001-300x300.jpg 300w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/dante-001-768x768.jpg 768w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/dante-001-1024x1024.jpg 1024w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/dante-001.jpg 1600w" sizes="(max-width: 500px) 100vw, 500px" />		<span class="product-title">Dante Studio Lightling</span>
	</a>

				
	<del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>415</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>399</span></ins>
	</li>
<li>
	
	<a href="https://merchandiser.wp-theme.design/shop/seating/runplus-black-leather-armchair/">
		<img width="500" height="500" src="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/runplus-001-500x500.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/runplus-001-500x500.jpg 500w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/runplus-001-100x100.jpg 100w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/runplus-001-960x960.jpg 960w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/runplus-001-150x150.jpg 150w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/runplus-001-300x300.jpg 300w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/runplus-001-768x768.jpg 768w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/runplus-001-1024x1024.jpg 1024w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/runplus-001.jpg 1600w" sizes="(max-width: 500px) 100vw, 500px" />		<span class="product-title">Runplus Black Leather Armchair</span>
	</a>

				
	<del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>205</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>200</span></ins>
	</li>
</ul></li><li class="widget woocommerce widget_top_rated_products"><h4 class="widget-title">Top Rated Products</h4><ul class="product_list_widget"><li>
	
	<a href="https://merchandiser.wp-theme.design/shop/kitchen-dining/watch-me-wall-clock/">
		<img width="500" height="500" src="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/watch-me-wall-clock-blue-990944-500x500.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/watch-me-wall-clock-blue-990944-500x500.jpg 500w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/watch-me-wall-clock-blue-990944-100x100.jpg 100w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/watch-me-wall-clock-blue-990944-960x960.jpg 960w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/watch-me-wall-clock-blue-990944-150x150.jpg 150w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/watch-me-wall-clock-blue-990944-300x300.jpg 300w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/watch-me-wall-clock-blue-990944-768x768.jpg 768w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/watch-me-wall-clock-blue-990944-1024x1024.jpg 1024w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/watch-me-wall-clock-blue-990944.jpg 1300w" sizes="(max-width: 500px) 100vw, 500px" />		<span class="product-title">Watch Me Wall Clock</span>
	</a>

			<div class="star-rating" role="img" aria-label="Rated 5.00 out of 5"><span style="width:100%">Rated <strong class="rating">5.00</strong> out of 5</span></div>	
	<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>35</span>
	</li>
<li>
	
	<a href="https://merchandiser.wp-theme.design/shop/seating/overlux-white-leather-chair/">
		<img width="500" height="500" src="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/overlux-001-500x500.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/overlux-001-500x500.jpg 500w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/overlux-001-100x100.jpg 100w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/overlux-001-960x960.jpg 960w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/overlux-001-150x150.jpg 150w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/overlux-001-300x300.jpg 300w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/overlux-001-768x768.jpg 768w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/overlux-001-1024x1024.jpg 1024w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/01/overlux-001.jpg 1600w" sizes="(max-width: 500px) 100vw, 500px" />		<span class="product-title">Overlux White Leather Chair</span>
	</a>

			<div class="star-rating" role="img" aria-label="Rated 5.00 out of 5"><span style="width:100%">Rated <strong class="rating">5.00</strong> out of 5</span></div>	
	<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>630</span>
	</li>
<li>
	
	<a href="https://merchandiser.wp-theme.design/shop/seating/variable-product/">
		<img width="500" height="500" src="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/variable-001-500x500.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/variable-001-500x500.jpg 500w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/variable-001-100x100.jpg 100w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/variable-001-960x960.jpg 960w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/variable-001-150x150.jpg 150w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/variable-001-300x300.jpg 300w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/variable-001-768x768.jpg 768w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/variable-001-1024x1024.jpg 1024w, https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/uploads/2016/05/variable-001.jpg 1600w" sizes="(max-width: 500px) 100vw, 500px" />		<span class="product-title">Variable Product</span>
	</a>

			<div class="star-rating" role="img" aria-label="Rated 5.00 out of 5"><span style="width:100%">Rated <strong class="rating">5.00</strong> out of 5</span></div>	
	
	</li>
</ul></li>	    </ul>

    </div>

                    <div class="myaccount-popup">
            <div class="woocommerce-account">
                <div class="woocommerce">
                


	<div class="u-columns col2-set" id="customer_login">

		<h2 class="loginTab active">Login</h2>
		<h2 class="registerTab">Register</h2>

		<div class="col-1 loginContainer">


		<form method="post" class="woocommerce-form woocommerce-form-login login">

			
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username">Username or email address <span class="required">*</span></label>
				<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="username" value="" />
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="password">Password <span class="required">*</span></label>
				<input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" />
			</p>

			
			<p class="lost_password">
				<label for="rememberme" class="inline">
					<input name="rememberme" type="checkbox" id="rememberme" value="forever" /> Remember me				</label>
				<a href="https://merchandiser.wp-theme.design/my-account/lost-password/">Lost your password?</a>
			</p>

			<p class="form-row sendbutton">
				<input type="hidden" id="woocommerce-login-nonce" name="woocommerce-login-nonce" value="f023c94391" /><input type="hidden" name="_wp_http_referer" value="/restserver.php" />				<button type="submit" class="button" name="login" value="Login" />Login</button>
			</p>
			
		</form>


	</div>

	<div class="u-column2 col-2 registerContainer">

		<form method="post" class="woocommerce-form woocommerce-form-register register"  >

			
			
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="reg_email">Email address <span class="required">*</span></label>
				<input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" value="" />
			</p>

			
				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
					<label for="reg_password">Password <span class="required">*</span></label>
					<input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" />
				</p>

			
			<!-- Spam Trap -->
			<div style="left: -999em; position: absolute;"><label for="trap">Anti-spam</label><input type="text" name="email_2" id="trap" tabindex="-1" /></div>

			<div class="woocommerce-privacy-policy-text"><p>Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our <a href="https://merchandiser.wp-theme.design/terms-privacy-policy/" class="woocommerce-privacy-policy-link" target="_blank">privacy policy</a>.</p>
</div>			
			<p class="woocomerce-FormRow form-row sendbutton">
				<input type="hidden" id="woocommerce-register-nonce" name="woocommerce-register-nonce" value="bce6331728" /><input type="hidden" name="_wp_http_referer" value="/restserver.php" />				<button type="submit" class="woocommerce-Button button" name="register" value="Register" />Register</button>
			</p>

			
		</form>

	</div>

</div>


                </div>
            </div>
        </div>
    
</header>    
<div class="site-header-mobiles"> 

    <div class="header-wrapper-mobiles">

        <div class="nav">

            <ul>
                <li class="menu-button">
                    <div class="tools_button">
                        <span class="tools_button_icon hamburger-menu-icon"></i></span> <span class="tools_button_text">Menu</span>
                    </div>
                </li>
            </ul>

        </div>

        <div class="site-branding">

            
                <div class="site-logo">
                    <a href="https://merchandiser.wp-theme.design/" rel="home">
                        
                        
                            <img src="//merchandiser.wp-theme.design/wp-content/uploads/2017/06/merchandiser-thumb.png" alt="logo">

                        
                    </a>
                </div>

            
        </div>

        <div class="tools">
            
            <ul>                
                
                <!-- Wishlist Button -->
                                                                
                <li class="wishlist-button show-for-large-up">
                    <a class="tools_button" href="https://merchandiser.wp-theme.design/wishlist/">
                        
                                                    
                            <span class="tools_button_icon wishlist-icon"></span>

                                                
                        <span class="wishlist_items_number">1</span>

                    </a>
                </li>

                                                
                <!-- Search Button -->
                                
                <li class="search-button">
                    <a class="tools_button">
                        
                            
                                                            
                                <span class="tools_button_icon search-icon"></span>

                            
                        
                    </a>
                </li>

                
                <!-- Shopping Bag Button -->
                                                
                <li class="shopping-bag-button">
                    <span class="tools_button">
                        
                                                    
                            <span class="tools_button_icon shopping-cart-icon"></span>

                                                
                        <span class="shopping_bag_items_number">8</span>

                    </span>
                </li>

                                
            </ul>

        </div>

    </div>

    <div class="search_wrapper">

        <div class="getbowtied_search_bar">
            
<div class="getbowtied-ajaxsearchform-container">
    <form class="woocommerce-product-search getbowtied-ajaxsearchform" role="search" method="get" action="https://merchandiser.wp-theme.design/">
        <div>
            <label class="screen-reader-text" for="getbowtied-s">Search for:</label>

            <input type="search"
                   value=""
                   name="s"
                   class="search-field getbowtied-s"
                   placeholder="Search products&hellip;"
                   data-loader-icon=""
                   data-min-chars="3"
                   title="Search for:" />

            <input type="submit" class="getbowtied-searchsubmit" value="Search" />
            <input type="hidden" name="post_type" value="product" />
        </div>
    </form>
</div>

        </div>

    </div>

</div>
    <div class="offcanvas_container">

        <div class="offcanvas_main_content">

            <div class="page-wrapper">

            	<div class="site-content">

	<div id="primary" class="content-area">
		<main id="main" class="site-main">
			<header class="page-header">
					<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
			</header><!-- .page-header -->

			<section class="error-404 not-found">
				<div class="page-content">

					<div class="icon-404"></div>
					
					<p>It looks like nothing was found at this location. Maybe try a search?</p>

				</div><!-- .page-content -->

				<form role="search" method="get" class="search-form" action="https://merchandiser.wp-theme.design/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form>
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->

    			
                <div class="site-content-overlay"></div>

                </div><!-- .site-content -->

                    			
<div class="footer-widget-wrapper">
    <ul class="footer-widget-area widget-area adjust_cols_height">
            </ul>
</div>


<footer class="site-footer">

	<div class="footer-wrapper">
		
		<div class="footer-socials">
		    <div class="shortcode_socials">
		        <ul class="mc_social_icons_list left">

		            
		                
		            
		                
		            
		                
		            
		                		                    
		                    <li class="mc_social_icon site-social-icons-pinterest">
		                        <a class="mc_social_icon_link"
		                        	target="_blank" 
		                        	href="http://www.getbowtied.com/">
		                        	<svg
		                        		xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
										width="16" height="16"
										viewBox="0 0 50 50"
										fill="#000">    
										<path d="M25,2C12.318,2,2,12.317,2,25s10.318,23,23,23s23-10.317,23-23S37.682,2,25,2z M27.542,32.719 c-3.297,0-4.516-2.138-4.516-2.138s-0.588,2.309-1.021,3.95s-0.507,1.665-0.927,2.591c-0.471,1.039-1.626,2.674-1.966,3.177 c-0.271,0.401-0.607,0.735-0.804,0.696c-0.197-0.038-0.197-0.245-0.245-0.678c-0.066-0.595-0.258-2.594-0.166-3.946 c0.06-0.88,0.367-2.371,0.367-2.371l2.225-9.108c-1.368-2.807-0.246-7.192,2.871-7.192c2.211,0,2.79,2.001,2.113,4.406 c-0.301,1.073-1.246,4.082-1.275,4.224c-0.029,0.142-0.099,0.442-0.083,0.738c0,0.878,0.671,2.672,2.995,2.672 c3.744,0,5.517-5.535,5.517-9.237c0-2.977-1.892-6.573-7.416-6.573c-5.628,0-8.732,4.283-8.732,8.214 c0,2.205,0.87,3.091,1.273,3.577c0.328,0.395,0.162,0.774,0.162,0.774l-0.355,1.425c-0.131,0.471-0.552,0.713-1.143,0.368 C15.824,27.948,13,26.752,13,21.649C13,16.42,17.926,11,25.571,11C31.64,11,37,14.817,37,21.001 C37,28.635,32.232,32.719,27.542,32.719z"></path>
									</svg>
		                        </a>
		                    </li>

		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		                
		            
		        </ul>
		    </div>
		    
		    </div>
		
		<nav class="footer-navigation" >
			<ul class="menu-footer-menu"><li id="menu-item-1571" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1571"><a href="http://themeforest.net/item/merchandiser-ecommerce-wordpress-theme-for-woocommerce/15791151?ref=getbowtied">Purchase Theme</a></li>
<li id="menu-item-1572" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1572"><a href="http://merchandiser.wp-theme.help/hc/en-us">Documentation</a></li>
<li id="menu-item-1573" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1573"><a href="http://merchandiser.wp-theme.help/hc/en-us">Support</a></li>
</ul>		</nav>

	</div>

</footer>

    			
    		</div><!-- .page-wrapper -->

    	</div><!-- .offcanvas_main_content -->

        <!-- OffCanvas Aside Content Left -->
        <div class="offcanvas_aside offcanvas_aside_left">
            <div class="offcanvas_aside_content">
            	<nav class="offcanvas_navigation">
	<ul class="offcanvas_menu">

		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-3566"><a href="http://merchandiser.wp-theme.design/">Home</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-4623"><a href="http://merchandiser.wp-theme.design/">Home</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-277"><a href="https://merchandiser.wp-theme.design/">Home V1 — Slider / eCommerce</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3851"><a href="https://merchandiser.wp-theme.design/home/home-v2-ecommerce-products/">Home V2 — eCommerce Products</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3964"><a href="https://merchandiser.wp-theme.design/home/home-v3-ecommerce-categories/">Home V3 — eCommerce Categories</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4383"><a href="https://merchandiser.wp-theme.design/home/home-v4-product-landing-page/">Home V4 — Product Landing Page</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3933"><a href="https://merchandiser.wp-theme.design/home/home-v5-full-width-categories/">Home V5 — Full-width Categories</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4011"><a href="https://merchandiser.wp-theme.design/home/home-v6-parallax-sections/">Home V6 — Parallax Sections</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3967"><a href="https://merchandiser.wp-theme.design/home/home-v7-categories-video/">Home V7 — Categories / Video</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3935"><a href="https://merchandiser.wp-theme.design/home/home-v8-full-width-categories-b/">Home V8 — Full-width Categories B</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4014"><a href="https://merchandiser.wp-theme.design/home/home-v9-product-collections/">Home V9 — Product Collections</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2801"><a href="https://merchandiser.wp-theme.design/home/splash-v1-coming-soon/">Splash V1 — Coming Soon</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4331"><a href="https://merchandiser.wp-theme.design/home/splash-v2-coming-soon/">Splash V2 — Coming Soon</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4338"><a href="https://merchandiser.wp-theme.design/home/splash-v3-coming-soon/">Splash V3 — Coming Soon</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-35"><a href="#">Secondary Pages</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4444"><a href="https://merchandiser.wp-theme.design/about-v1/">About V1</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4443"><a href="https://merchandiser.wp-theme.design/about-v2/">About V2</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1574"><a href="https://merchandiser.wp-theme.design/about-v3/">About V3</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1581"><a href="https://merchandiser.wp-theme.design/faqs/">FAQs</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1580"><a href="https://merchandiser.wp-theme.design/contact/">Contact V1</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4551"><a href="https://merchandiser.wp-theme.design/contact-v2/">Contact V2</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-31"><a href="#">Blog</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4562"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=c830085a-aa15-4d23-913a-085d39737d74">Blog Layout V1</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4563"><a href="http://merchandiser.wp-theme.design/blog/?no-preset">Blog Layout V2</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4564"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=5daf0f96-196c-4dcd-a128-cf86243f8313">Blog Layout V3</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4565"><a href="http://merchandiser.wp-theme.design/100-scandinavian-with-twee-wayfarers/?customize_changeset_uuid_gbt=41798d90-a6a5-4eeb-83e7-352f0e705bf7">Single Post V1</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4566"><a href="http://merchandiser.wp-theme.design/100-scandinavian-with-twee-wayfarers/?no-preset">Single Post V2</a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-22"><a href="https://merchandiser.wp-theme.design/shop/">Shop</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-43"><a href="https://merchandiser.wp-theme.design/shop/">Shop</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5140"><a href="https://merchandiser.wp-theme.design/shop/?no-preset">Shop — with Sidebar</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3567"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=efa1526c-e903-4001-a749-5b2ef44f4b9c">Shop — No Sidebar</a></li>
		<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2803"><a href="https://merchandiser.wp-theme.design/product-category/kitchen-dining/">Shop — A Product Category</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4567"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=47fba0d9-8937-4558-9fce-9c7674ceeafe">Shop — 1 Products</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3368"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=ca6421d5-d034-49c2-86fc-aa12d4acc299">Shop — 2 Products</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3369"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=a8d7e476-3bd4-4744-b6a3-510f2c693d5a">Shop — 3 Products</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3370"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=563b31d7-045e-468a-97ec-3fc62d2f0972">Shop — 4 Products</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3371"><a href="http://merchandiser.wp-theme.design/shop/?no-preset">Shop — 5 Products</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3372"><a href="http://merchandiser.wp-theme.design/shop/?customize_changeset_uuid_gbt=9332327f-24ed-42d8-a919-c6f39bd8abdd">Shop — 6 Products</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-40"><a href="#">Products</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-53"><a href="https://merchandiser.wp-theme.design/shop/seating/simple-product/">Simple Product</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-2628"><a href="https://merchandiser.wp-theme.design/shop/seating/purple-dining-chair/">Variable Product <sup>Color / Size / Custom</sup></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-59"><a href="https://merchandiser.wp-theme.design/shop/seating/external-affiliate-product/">External / Affiliate Product</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-2581"><a href="https://merchandiser.wp-theme.design/shop/kitchen-dining/hi-cut-transparent-chair/">Grouped Product</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1399"><a href="https://merchandiser.wp-theme.design/shop/kitchen-dining/clear-swingtop-bottles/">Out of Stock</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-2804"><a href="https://merchandiser.wp-theme.design/shop/seating/fivee-houseplant-pot/">Product on Sale</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-41"><a href="#">Orders</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18"><a href="https://merchandiser.wp-theme.design/cart/">Shopping Cart</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19"><a href="https://merchandiser.wp-theme.design/checkout/">Checkout</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-42"><a href="https://merchandiser.wp-theme.design/my-account/">Login / Register</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="https://merchandiser.wp-theme.design/my-account/">My Account</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-68"><a href="https://merchandiser.wp-theme.design/order-tracking/">Order Tracking</a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-has-children menu-item-26"><a href="https://merchandiser.wp-theme.design/blog/">Blog</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-has-children menu-item-4568"><a href="https://merchandiser.wp-theme.design/blog/">Blog Layouts</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4577"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=c830085a-aa15-4d23-913a-085d39737d74">Blog — Layout V1</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4578"><a href="http://merchandiser.wp-theme.design/blog/?no-preset">Blog — Layout V2</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4579"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=5daf0f96-196c-4dcd-a128-cf86243f8313">Blog — Layout V3</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-has-children menu-item-4569"><a href="https://merchandiser.wp-theme.design/100-scandinavian-with-twee-wayfarers/">Single Posts</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4575"><a href="http://merchandiser.wp-theme.design/100-scandinavian-with-twee-wayfarers/?customize_changeset_uuid_gbt=41798d90-a6a5-4eeb-83e7-352f0e705bf7">Blog — Single Post V1</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4576"><a href="http://merchandiser.wp-theme.design/100-scandinavian-with-twee-wayfarers/?no-preset">Blog — Single Post V2</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-has-children menu-item-4571"><a href="https://merchandiser.wp-theme.design/blog/">Pagination</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4572"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=c361be75-5448-4e69-b05f-2e7fd0f9fe8f">Pagination — Classic</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4573"><a href="http://merchandiser.wp-theme.design/blog/?customize_changeset_uuid_gbt=9615284b-5fc7-454b-9f73-bf05ec275056">Pagination — Load More</a></li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4574"><a href="http://merchandiser.wp-theme.design/blog/?no-preset">Pagination — Infinite</a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-3624"><a href="#">Elements</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4384"><a href="#">Page Builder Products</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-147"><a href="https://merchandiser.wp-theme.design/elements/product-categories-grid/">Product Categories Grid</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-146"><a href="https://merchandiser.wp-theme.design/elements/recent-products/">Recent Products</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-145"><a href="https://merchandiser.wp-theme.design/elements/products-by-category/">Products by Category</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-144"><a href="https://merchandiser.wp-theme.design/elements/products-by-attribute/">Products by Attribute</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-143"><a href="https://merchandiser.wp-theme.design/elements/top-rated-products/">Top Rated Products</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-142"><a href="https://merchandiser.wp-theme.design/elements/best-selling-products/">Best Selling Products</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-141"><a href="https://merchandiser.wp-theme.design/elements/featured-products/">Featured Products</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-140"><a href="https://merchandiser.wp-theme.design/elements/products-on-sale/">Products on Sale</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-139"><a href="https://merchandiser.wp-theme.design/elements/products-custom-list/">Products – Custom List</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-138"><a href="https://merchandiser.wp-theme.design/elements/add-to-cart-button/">Add to Cart Button</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-137"><a href="https://merchandiser.wp-theme.design/elements/single-product/">Single Product</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4447"><a href="#">Page Builder Content</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-163"><a href="https://merchandiser.wp-theme.design/elements/banners/">Banners</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1466"><a href="https://merchandiser.wp-theme.design/elements/tabs/">Tabs</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1778"><a href="https://merchandiser.wp-theme.design/elements/toggles-faqs/">Toggles / FAQs</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1464"><a href="https://merchandiser.wp-theme.design/elements/accordions/">Accordions</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-161"><a href="https://merchandiser.wp-theme.design/elements/social-media/">Social Media</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1884"><a href="https://merchandiser.wp-theme.design/elements/images-image-galleries/">Image Galleries</a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4479"><a href="https://merchandiser.wp-theme.design/merchandiser-ecommerce-wordpress-theme/">Features</a></li>

		<!-- Wishlist Button -->
                                
            <li class="wishlist-button has-border">
                <a class="tools_button" href="https://merchandiser.wp-theme.design/wishlist/">
                    
                    Wishlist
                </a>
            </li>

                        		

					
			
				<li class="has-border">
					<a href="https://merchandiser.wp-theme.design/my-account/">My account</a>
				</li>

				
			
				
	</ul>
</nav>
<div class="offcanvas_left_close offcanvas_close"><span class="offcanvas-close-icon"></span></div>

<div class="offcanvas_sidebars">
</div>            </div>
        </div>

        <!-- OffCanvas Aside Content Right -->
        <div class="offcanvas_aside offcanvas_aside_right">        
            <div class="offcanvas_aside_content">
            	<div class="offcanvas_minicart">
	<div class="offcanvas_right_close offcanvas_close"><span class="offcanvas-close-icon"></span></div>
	<div class="widget woocommerce widget_shopping_cart"><h2 class="widgettitle">Cart</h2><div class="widget_shopping_cart_content"></div></div></div>

<div class="offcanvas_quickview woocommerce">
	
	<div class="overlay-loader">
	    <img class="loader-icon spinning" src="https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/themes/merchandiser/images/loader.svg" alt="loader">
	</div>

	<div class="offcanvas_quickview_content"><!-- Quick view content --></div>

</div>            </div>
        </div>

        
        <div class="offcanvas_overlay"></div>

    </div><!-- .offcanvas_container -->

    <!-- ******************************************************************** -->
    <!-- * Back To Top Button *********************************************** -->
    <!-- ******************************************************************** -->

            <a href="#0" class="cd-top"></a>
    
    <script>
    jQuery(document).ready(function () {
		jQuery.post('https://merchandiser.wp-theme.design?ga_action=googleanalytics_get_script', {action: 'googleanalytics_get_script'}, function(response) {
			var s = document.createElement("script");
			s.type = "text/javascript";
			s.innerHTML = response;
			jQuery("head").append(s);
		});
    });
</script>	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
			<script type="text/javascript">
			var wc_product_block_data = JSON.parse( decodeURIComponent( '%7B%22min_columns%22%3A1%2C%22max_columns%22%3A6%2C%22default_columns%22%3A3%2C%22min_rows%22%3A1%2C%22max_rows%22%3A6%2C%22default_rows%22%3A1%2C%22thumbnail_size%22%3A300%2C%22placeholderImgSrc%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fwp-content%5C%2Fuploads%5C%2Fwoocommerce-placeholder.png%22%2C%22min_height%22%3A500%2C%22default_height%22%3A500%2C%22isLargeCatalog%22%3Afalse%2C%22limitTags%22%3Afalse%2C%22hasTags%22%3Atrue%2C%22productCategories%22%3A%5B%7B%22term_id%22%3A179%2C%22name%22%3A%22Uncategorized%22%2C%22slug%22%3A%22uncategorized%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A179%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Funcategorized%5C%2F%22%7D%2C%7B%22term_id%22%3A160%2C%22name%22%3A%22Art%20%26amp%3B%20Frames%22%2C%22slug%22%3A%22art-frames%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A160%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Celiac%20cornhole%20vice%20neutra.%20Succulents%20freegan%20four%20dollar%20toast%20pop-up%2C%20meggings%20brooklyn%20flexitarian%20irony%20snackwave.%20%22%2C%22parent%22%3A140%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-c%5C%2Fart-frames%5C%2F%22%7D%2C%7B%22term_id%22%3A155%2C%22name%22%3A%22Bathroom%20Accessories%22%2C%22slug%22%3A%22bathroom-accessories%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A155%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A139%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-b%5C%2Fbathroom-accessories%5C%2F%22%7D%2C%7B%22term_id%22%3A157%2C%22name%22%3A%22Bedding%22%2C%22slug%22%3A%22bedding%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A157%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A139%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-b%5C%2Fbedding%5C%2F%22%7D%2C%7B%22term_id%22%3A161%2C%22name%22%3A%22Bowls%20%26amp%3B%20Vases%22%2C%22slug%22%3A%22bowls-vases%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A161%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Stumptown%20raw%20denim%20bicycle%20rights%2C%20beard%20single-origin%20coffee%22%2C%22parent%22%3A140%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-c%5C%2Fbowls-vases%5C%2F%22%7D%2C%7B%22term_id%22%3A154%2C%22name%22%3A%22Ceiling%20Lightning%22%2C%22slug%22%3A%22ceiling-lightning%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A154%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A139%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-b%5C%2Fceiling-lightning%5C%2F%22%7D%2C%7B%22term_id%22%3A156%2C%22name%22%3A%22Ceramics%22%2C%22slug%22%3A%22ceramics%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A156%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Photo%20booth%20tousled%20selvage%20banh%20mi%2C%20kogi%20hoodie%20cray.%20Pop-up%20deep%20v%20butcher%2C%20gentrify%20godard%20art%20party%20small%20batch.%22%2C%22parent%22%3A139%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-b%5C%2Fceramics%5C%2F%22%7D%2C%7B%22term_id%22%3A162%2C%22name%22%3A%22Clocks%22%2C%22slug%22%3A%22clocks%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A162%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Brooklyn%20vexillologist%20vice%20chia%20keytar%22%2C%22parent%22%3A140%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-c%5C%2Fclocks%5C%2F%22%7D%2C%7B%22term_id%22%3A163%2C%22name%22%3A%22Decorative%20Objects%22%2C%22slug%22%3A%22decorative-objects%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A163%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Kale%20chips%20master%20cleanse%20chambray%20street%20art%20vaporware%2C%20chicharrones%20mumblecore%20af%20photo%20booth%20four%20loko%20migas%20mixtape%20banjo%20aesthetic%20brunch%22%2C%22parent%22%3A140%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-c%5C%2Fdecorative-objects%5C%2F%22%7D%2C%7B%22term_id%22%3A164%2C%22name%22%3A%22Design%20Miniatures%22%2C%22slug%22%3A%22design-miniatures%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A164%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Waistcoat%20williamsburg%20chartreuse%2C%20twee%20roof%20party%20pop-up%20brunch.%22%2C%22parent%22%3A140%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-c%5C%2Fdesign-miniatures%5C%2F%22%7D%2C%7B%22term_id%22%3A166%2C%22name%22%3A%22Floor%20Lamps%22%2C%22slug%22%3A%22floor-lamps%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A166%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Lumbersexual%20kombucha%20chambray%20narwhal%20fam%20wolf%20bespoke%2C%20pug%20chia%20mixtape.%20%22%2C%22parent%22%3A140%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-c%5C%2Ffloor-lamps%5C%2F%22%7D%2C%7B%22term_id%22%3A169%2C%22name%22%3A%22Frames%22%2C%22slug%22%3A%22frames%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A169%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A141%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-d%5C%2Fframes%5C%2F%22%7D%2C%7B%22term_id%22%3A159%2C%22name%22%3A%22Hooks%20%26amp%3B%20Coatstands%22%2C%22slug%22%3A%22hooks-coatstands%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A159%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A139%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-b%5C%2Fhooks-coatstands%5C%2F%22%7D%2C%7B%22term_id%22%3A153%2C%22name%22%3A%22Kitchenware%22%2C%22slug%22%3A%22kitchenware%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A153%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Tousled%20polaroid%20narwhal%20cliche%22%2C%22parent%22%3A139%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-b%5C%2Fkitchenware%5C%2F%22%7D%2C%7B%22term_id%22%3A168%2C%22name%22%3A%22Knitwork%22%2C%22slug%22%3A%22knitwork%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A168%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Subway%20tile%20vegan%20offal%20put%20a%20bird%20on%20it%20mixtape%22%2C%22parent%22%3A141%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-d%5C%2Fknitwork%5C%2F%22%7D%2C%7B%22term_id%22%3A152%2C%22name%22%3A%22Living%20Room%22%2C%22slug%22%3A%22living-room%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A152%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A139%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-b%5C%2Fliving-room%5C%2F%22%7D%2C%7B%22term_id%22%3A167%2C%22name%22%3A%22Stools%20%26amp%3B%20Benches%22%2C%22slug%22%3A%22stools-benches%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A167%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Craft%20beer%20leggings%20street%20art%20%22%2C%22parent%22%3A140%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-c%5C%2Fstools-benches%5C%2F%22%7D%2C%7B%22term_id%22%3A165%2C%22name%22%3A%22Storage%22%2C%22slug%22%3A%22storage%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A165%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Selfies%20art%20party%20everyday%22%2C%22parent%22%3A140%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-c%5C%2Fstorage%5C%2F%22%7D%2C%7B%22term_id%22%3A158%2C%22name%22%3A%22Thank%20You%20Cards%22%2C%22slug%22%3A%22thank-you-cards%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A158%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A139%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-b%5C%2Fthank-you-cards%5C%2F%22%7D%2C%7B%22term_id%22%3A137%2C%22name%22%3A%22Categories%20Grid%22%2C%22slug%22%3A%22categories-grid%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A137%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2F%22%7D%2C%7B%22term_id%22%3A138%2C%22name%22%3A%22Grid%20A%22%2C%22slug%22%3A%22grid-a%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A138%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A137%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-a%5C%2F%22%7D%2C%7B%22term_id%22%3A142%2C%22name%22%3A%22Furniture%22%2C%22slug%22%3A%22furniture%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A142%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A138%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-a%5C%2Ffurniture%5C%2F%22%7D%2C%7B%22term_id%22%3A145%2C%22name%22%3A%22Bathroom%22%2C%22slug%22%3A%22bathroom%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A145%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A138%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-a%5C%2Fbathroom%5C%2F%22%7D%2C%7B%22term_id%22%3A148%2C%22name%22%3A%22Bedroom%22%2C%22slug%22%3A%22bedroom%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A148%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A138%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-a%5C%2Fbedroom%5C%2F%22%7D%2C%7B%22term_id%22%3A147%2C%22name%22%3A%22Garden%22%2C%22slug%22%3A%22garden%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A147%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A138%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-a%5C%2Fgarden%5C%2F%22%7D%2C%7B%22term_id%22%3A149%2C%22name%22%3A%22Gifts%22%2C%22slug%22%3A%22gifts%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A149%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A138%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-a%5C%2Fgifts%5C%2F%22%7D%2C%7B%22term_id%22%3A146%2C%22name%22%3A%22Home%20%26amp%3B%20Deco%22%2C%22slug%22%3A%22home-deco%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A146%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A138%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-a%5C%2Fhome-deco%5C%2F%22%7D%2C%7B%22term_id%22%3A143%2C%22name%22%3A%22Kitchen%20%26amp%3B%20Dining%22%2C%22slug%22%3A%22kitchen-dining-grid-a%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A143%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A138%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-a%5C%2Fkitchen-dining-grid-a%5C%2F%22%7D%2C%7B%22term_id%22%3A144%2C%22name%22%3A%22Lightning%22%2C%22slug%22%3A%22lightning%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A144%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A138%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-a%5C%2Flightning%5C%2F%22%7D%2C%7B%22term_id%22%3A139%2C%22name%22%3A%22Grid%20B%22%2C%22slug%22%3A%22grid-b%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A139%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A137%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-b%5C%2F%22%7D%2C%7B%22term_id%22%3A140%2C%22name%22%3A%22Grid%20C%22%2C%22slug%22%3A%22grid-c%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A140%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A137%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-c%5C%2F%22%7D%2C%7B%22term_id%22%3A141%2C%22name%22%3A%22Grid%20D%22%2C%22slug%22%3A%22grid-d%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A141%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A137%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fcategories-grid%5C%2Fgrid-d%5C%2F%22%7D%2C%7B%22term_id%22%3A30%2C%22name%22%3A%22Furniture%22%2C%22slug%22%3A%22seating%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A30%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A42%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fseating%5C%2F%22%7D%2C%7B%22term_id%22%3A9%2C%22name%22%3A%22Kitchen%20%26amp%3B%20Dining%22%2C%22slug%22%3A%22kitchen-dining%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A9%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22Kitchen%20sink%20realism%20%28or%20kitchen%20sink%20drama%29%20is%20a%20term%20coined%20to%20describe%20a%20British%20cultural%20movement%20that%20developed%20in%20the%20late%201950s%20and%20early%201960s%20in%20theatre%2C%20art%2C%20novels%2C%20film%20and%20television%20plays%2C%20whose%20protagonists%20usually%20could%20be%20described%20as%20%5C%22angry%20young%20men%5C%22%20who%20were%20disillusioned%20with%20modern%20society.%20Wikipedia%22%2C%22parent%22%3A0%2C%22count%22%3A12%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fkitchen-dining%5C%2F%22%7D%2C%7B%22term_id%22%3A116%2C%22name%22%3A%22Lighting%22%2C%22slug%22%3A%22lighting%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A116%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A9%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Flighting%5C%2F%22%7D%2C%7B%22term_id%22%3A133%2C%22name%22%3A%22Kitchen%22%2C%22slug%22%3A%22kitchen%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A133%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A2%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fkitchen%5C%2F%22%7D%2C%7B%22term_id%22%3A130%2C%22name%22%3A%22Vintage%22%2C%22slug%22%3A%22vintage%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A130%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A2%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Fvintage%5C%2F%22%7D%2C%7B%22term_id%22%3A129%2C%22name%22%3A%22Accessories%22%2C%22slug%22%3A%22accessories%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A129%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A4%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2Fproduct-category%5C%2Faccessories%5C%2F%22%7D%5D%2C%22homeUrl%22%3A%22https%3A%5C%2F%5C%2Fmerchandiser.wp-theme.design%5C%2F%22%7D' ) );
		</script>
		<script type='text/javascript'>
/* <![CDATA[ */
var yith_wcwl_l10n = {"ajax_url":"\/wp-admin\/admin-ajax.php","redirect_to_cart":"no","multi_wishlist":"","hide_add_button":"1","is_user_logged_in":"","ajax_loader_url":"https:\/\/merchandiser.wp-theme.design\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader.gif","remove_from_wishlist_after_add_to_cart":"yes","labels":{"cookie_disabled":"We are sorry, but this feature is available only if cookies are enabled on your browser.","added_to_cart_message":"<div class=\"woocommerce-message\">Product correctly added to cart<\/div>"},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist","move_to_another_wishlist_action":"move_to_another_wishlsit","reload_wishlist_and_adding_elem_action":"reload_wishlist_and_adding_elem"}};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_b402d952b04d098995c4a8b42d48a13f","fragment_name":"wc_fragments_b402d952b04d098995c4a8b42d48a13f","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var getbowtied_scripts_vars = {"ajax_load_more_locale":"Load More Items","ajax_loading_locale":"Loading","ajax_no_more_items_locale":"No more items available.","mobile_menu_title":"Menu","blog_pagination_type":"infinite_scroll","blog_layout":"blog_layout_1","shop_pagination_type":"infinite_scroll","shop_layout_style":"regular","ajax_url":"https:\/\/merchandiser.wp-theme.design\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var pwsL10n = {"unknown":"Password strength unknown","short":"Very weak","bad":"Weak","good":"Medium","strong":"Strong","mismatch":"Mismatch"};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_password_strength_meter_params = {"min_password_strength":"3","stop_checkout":"","i18n_password_error":"Please enter a stronger password.","i18n_password_hint":"Hint: The password should be at least twelve characters long. To make it stronger, use upper and lower case letters, numbers, and symbols like ! \" ? $ % ^ & )."};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var getbowtied_wcas_params = {"loading":"https:\/\/merchandiser.wp-theme.design\/wp-content\/themes\/merchandiser\/images\/loader.svg","ajax_url":"https:\/\/merchandiser.wp-theme.design\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://merchandiser-szcel9eb49h.stackpathdns.com/wp-content/plugins/bwp-minify/cache/minify-b1-jquery-selectBox-6dceda036a699597597c54a416217910.js?ver=1568217794'></script>

</body>
</html>
<!-- Page not cached by WP Super Cache. 404. -->